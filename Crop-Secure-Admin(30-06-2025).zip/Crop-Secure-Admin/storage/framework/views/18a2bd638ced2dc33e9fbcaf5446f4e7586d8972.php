
<?php $__env->startSection('title', 'Insurance History'); ?>
<?php $__env->startSection('content'); ?>


    <div class="main-content" style="min-height: 562px;">
        <section class="section">
            <div class="section-body">
                <div class="row">
                    <div class="col-12 col-md-12 col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <div class="col-12">
                                    <h4>Insurance History</h4>
                                </div>
                            </div>
                            <div class="card-body table-striped table-bordered table-responsive">

                                <table class="table responsive" id="table_id_events">
                                    <thead>
                                        <tr>
                                            <th>Sr.</th>
                                            <th>Name</th>
                                            <th>Crop</th>
                                            <th>Area Unit</th>
                                            <th>Area</th>
                                            <th>Land</th>
                                            <th>Insurance Type</th>
                                            <th>District</th>
                                            <th>Tehsil</th>
                                            <th>Company</th>
                                            <th>Premium Price</th>
                                            <th>Sum Insured</th>
                                            <th>Payable Amount</th>
                                            <th>Benchmark</th>
                                            <th>Benchmark Price</th>
                                            <th>Receipt Number</th>
                                            <th scope="col">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($index + 1); ?></td>
                                                <td><?php echo e($history->farmer_name ?? '-'); ?></td>
                                                <td><?php echo e($history->crop ?? '-'); ?></td>
                                                <td><?php echo e($history->area_unit ?? '-'); ?></td>
                                                <td><?php echo e($history->area ?? '-'); ?></td>
                                                <td><?php echo e($history->land ?? '-'); ?></td>
                                                <td><?php echo e($history->insurance_type ?? '-'); ?></td>
                                                <td><?php echo e($history->district ?? '-'); ?></td>
                                                <td><?php echo e($history->tehsil ?? '-'); ?></td>
                                                <td><?php echo e($history->company ?? '-'); ?></td>
                                                <td><?php echo e($history->premium_price ?? '-'); ?></td>
                                                <td><?php echo e($history->sum_insured ?? '-'); ?></td>
                                                <td><?php echo e($history->payable_amount ?? '-'); ?></td>
                                                <td><?php echo e($history->benchmark ?? '-'); ?></td>
                                                <td><?php echo e($history->benchmark_price ?? '-'); ?></td>
                                                <td><?php echo e($history->receipt_number ?? '-'); ?></td>
                                                <td>
                                                    <!-- Actions like delete/edit if needed -->
                                                    <form action="<?php echo e(route('insurance-history.destroy', $history->id)); ?>"
                                                        method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit"
                                                            class="btn btn-danger show_confirm">Delete</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="17">No insurance history found.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>

                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script>
        $(document).ready(function() {
            $('#table_id_events').DataTable()
        })
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
    <script type="text/javascript">
        $('.show_confirm').click(function(event) {
            var form = $(this).closest("form");
            var name = $(this).data("name");
            event.preventDefault();
            swal({
                    title: `Are you sure you want to delete this record?`,
                    text: "If you delete this, it will be gone forever.",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        form.submit();
                    }
                });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Crop-Secure-Admin\resources\views/admin/ensured_crops/index.blade.php ENDPATH**/ ?>