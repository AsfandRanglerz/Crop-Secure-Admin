<?php $__env->startComponent('mail::message'); ?>
Dear <?php echo e($message['name']); ?>,

Your account as a Sub-Admin has been successfully created. Below are your login credentials:

**Email:** <?php echo e($message['email']); ?>


**Password:** <?php echo e($message['password']); ?>



Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\Crop-Secure-Admin\resources\views/emails/subadmin_login_password.blade.php ENDPATH**/ ?>