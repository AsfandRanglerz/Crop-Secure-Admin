
<?php $__env->startSection('title', 'Insurance Sub-Types'); ?>
<?php $__env->startSection('content'); ?>



    <!-- Add Insurance Sub-Types Modal -->
<div class="modal fade" id="InsuranceTypesModal" tabindex="-1" role="dialog" aria-labelledby="InsuranceTypesModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form action="<?php echo e(route('insurance.sub.type.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="InsuranceTypesModalLabel">Add Insurance Sub-Type</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span>&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <input type="hidden" name="incurance_type_id" value="<?php echo e($InsuranceType->id); ?>">

                    <div class="row">
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="name">Crop</label>
                                <select name="name" class="form-control">
                                    <option value="">Select Crop</option>
                                    <?php $__currentLoopData = $ensuredCrops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($crop->name); ?>" <?php echo e(old('name') == $crop->name ? 'selected' : ''); ?>>
                                            <?php echo e($crop->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="district_id">District</label>
                                <select id="districtAdd" name="district_id" class="form-control">
                                    <option value="">Select District</option>
                                    <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($district->id); ?>"><?php echo e($district->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['district_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="tehsil_id">Tehsil</label>
                                <select id="tehsilAdd" name="tehsil_id" class="form-control">
                                    <option value="">Select Tehsil</option>
                                </select>
                                <?php $__errorArgs = ['tehsil_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="current_yield">Current Yield</label>
                                <div class="input-group">
                                    <input type="number" name="current_yield" class="form-control" value="<?php echo e(old('current_yield')); ?>">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text font-weight-bold">%</span>
                                    </div>
                                </div>
                                <?php $__errorArgs = ['current_yield'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="year">Year</label>
                                <input type="text" name="year" class="form-control" value="<?php echo e(old('year', now()->year)); ?>" readonly>
                                <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div> <!-- end .row -->
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </div>
        </form>
    </div>
</div>

    


 <?php $__currentLoopData = $InsuranceSubTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $InsuranceSubType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="EditInsuranceTypesModal-<?php echo e($InsuranceSubType->id); ?>" tabindex="-1" role="dialog"
    aria-labelledby="EditInsuranceTypesModalLabel" aria-hidden="true" data-id="<?php echo e($InsuranceSubType->id); ?>"
    data-district-id="<?php echo e($InsuranceSubType->district_id); ?>"
    data-tehsil-id="<?php echo e($InsuranceSubType->tehsil_id); ?>">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit</h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
            </div>
            <form action="<?php echo e(route('insurance.sub.type.update', $InsuranceSubType->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                <div class="modal-body">
                    <input type="hidden" name="incurance_type_id" value="<?php echo e($InsuranceType->id); ?>">
                    <div class="row">
                        <!-- Crop -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="name">Crop</label>
                                <select name="name" class="form-control form-select">
                                    <option value="">Select Crop</option>
                                    <?php $__currentLoopData = $ensuredCrops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($crop->name); ?>"
                                            <?php echo e(old('name', $InsuranceSubType->name) == $crop->name ? 'selected' : ''); ?>>
                                            <?php echo e($crop->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <!-- District -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="district_id">District</label>
                                <select class="form-control form-select district-select" name="district_id"
                                    data-id="<?php echo e($InsuranceSubType->id); ?>">
                                    <option value="">Select District</option>
                                    <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($district->id); ?>"
                                            <?php echo e(old('district_id', $InsuranceSubType->district_id) == $district->id ? 'selected' : ''); ?>>
                                            <?php echo e($district->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <!-- Tehsil -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="tehsil_id">Tehsil</label>
                                <select class="form-control form-select tehsil-select" name="tehsil_id"
                                    id="tehsilEdit-<?php echo e($InsuranceSubType->id); ?>">
                                    <option value="">Select Tehsil</option>
                                    
                                </select>
                            </div>
                        </div>

                        <!-- Current Yield -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="current_yield">Current yield</label>
                                <div class="input-group">
                                    <input type="text" name="current_yield" class="form-control"
                                        value="<?php echo e(old('current_yield', $InsuranceSubType->current_yield)); ?>">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text font-weight-bold">%</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Year -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="year">Year</label>
                                <input type="text" name="year" class="form-control"
                                    value="<?php echo e(old('year', $InsuranceSubType->year)); ?>" readonly>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   





    <div class="main-content" style="min-height: 562px;">
        <section class="section">
            <div class="section-body">
                <div class="row">
                    <div class="col-12 col-md-12 col-lg-12">
                        <a class="btn btn-primary mb-2" href="<?php echo e(route('insurance.type.index')); ?>">Back</a>
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h4 class="mb-0"><?php echo e($InsuranceType->name); ?></h4>
                                
                                <div class="d-flex gap-5">
                                    <select id="cropFilter" class="form-control form-select w-auto rounded mr-2" >
                                        <option value="">Crops</option>
                                        <?php $__currentLoopData = $InsuranceSubTypes->pluck('name')->unique(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($name); ?>"><?php echo e($name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                
                                    <select id="districtFilter" class="form-control form-select w-auto rounded mr-2" >
                                        <option value="">Districts</option>
                                        <?php $__currentLoopData = $InsuranceSubTypes->pluck('district.name')->unique(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($district); ?>"><?php echo e($district); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                
                                    <select id="tehsilFilter" class="form-control form-select w-auto rounded mr-2" >
                                        <option value="">Tehsil</option>
                                        <?php $__currentLoopData = $InsuranceSubTypes->pluck('tehsil.name')->unique(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tehsil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tehsil); ?>"><?php echo e($tehsil); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                
                                    <select id="yearFilter" class="form-control form-select w-auto rounded mr-2" >
                                        <option value="">Year</option>
                                        <?php $__currentLoopData = $InsuranceSubTypes->pluck('year')->unique(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                
                            </div>
                            <div class="card-body table-striped table-bordered table-responsive">
                                <?php if(Auth::guard('admin')->check() ||
                                        $sideMenuPermissions->contains(fn($permission) => $permission['side_menu_name'] === 'Insurance Types' &&
                                                $permission['permissions']->contains('create'))): ?>
                                    <a class="btn btn-primary mb-3 text-white" href="#" data-toggle="modal"
                                    data-target="#InsuranceTypesModal">Create</a>
                                <?php endif; ?>

                                <table class="table responsive" id="table_id_events">
                                    <thead>
                                        <tr>
                                            <th>Sr.</th>
                                            <th>Crop</th>
                                            <th>District</th>
                                            <th>Tehsil</th>
                                            <th>Current Yield</th>
                                            <th>Year</th>
                                            <th scope="col">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $InsuranceSubTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $InsuranceSubType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td class="crop"><?php echo e($InsuranceSubType->name); ?></td>
                                            <td class="district"><?php echo e($InsuranceSubType->district->name ?? 'No district'); ?></td>
                                            <td class="tehsil"><?php echo e($InsuranceSubType->tehsil->name ?? 'No tehsil'); ?></td>                                            
                                            <td><?php echo e($InsuranceSubType->current_yield); ?>%</td>
                                            <td class="year"><?php echo e($InsuranceSubType->year); ?></td>
                                            
                                            <td>
                                                <div class="d-flex gap-4">
                                                    <?php if(Auth::guard('admin')->check() ||
                                                            $sideMenuPermissions->contains(fn($permission) => $permission['side_menu_name'] === 'Insurance Types' &&
                                                                    $permission['permissions']->contains('edit'))): ?>
                                                        <a class="btn btn-primary text-white"
                                                            href="#" data-toggle="modal" data-target="#EditInsuranceTypesModal-<?php echo e($InsuranceSubType->id); ?>">Edit</a>
                                                    <?php endif; ?>

                                                    <!-- Delete Button -->
                                                    <?php if(Auth::guard('admin')->check() ||
                                                            $sideMenuPermissions->contains(fn($permission) => $permission['side_menu_name'] === 'Insurance Types' &&
                                                                    $permission['permissions']->contains('delete'))): ?>
                                                        <form action="
                                                        <?php echo e(route('insurance.sub.type.destroy', $InsuranceSubType->id)); ?>

                                                            " method="POST" 
                                                            style="display:inline-block; margin-left: 10px">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <input type="hidden" name="incurance_type_id" value="<?php echo e($InsuranceType->id); ?>">
                                                            <button type="submit"
                                                                class="btn btn-danger btn-flat show_confirm"
                                                                data-toggle="tooltip">Delete</button>
                                                        </form>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

<?php $__env->stopSection(); ?>

    
<?php $__env->startSection('js'); ?>


<script>
    $(document).ready(function () {
        /** ========== ADD FORM HANDLING ========== */
    
    $('#districtAdd').change(function () {
        let districtId = $(this).val();
        let tehsilDropdown = $('#tehsilAdd');

        tehsilDropdown.html('<option value="">Loading...</option>');

        if (districtId) {
            $.ajax({
                url: `<?php echo e(route('get.tehsils', ':districtId')); ?>`.replace(':districtId', districtId),
                method: 'GET',
                success: function (data) {
                    tehsilDropdown.empty().append('<option value="">Select Tehsil</option>');
                    data.forEach(function (tehsil) {
                        tehsilDropdown.append(`<option value="${tehsil.id}">${tehsil.name}</option>`);
                    });
                },
                error: function (xhr) {
                    console.error('Error fetching tehsils:', xhr);
                    tehsilDropdown.html('<option value="">Failed to load</option>');
                }
            });
        } else {
            tehsilDropdown.html('<option value="">Select Tehsil</option>');
        }
    });


        /** ========== EDIT FORM HANDLING ========== */
        function loadTehsilsForEdit(districtId, selectedTehsil = null) {
            $('#tehsilEdit').empty().append('<option value="">Select Tehsil</option>');
    
            if (districtId) {
                $.ajax({
                    url: `<?php echo e(route('get.tehsils', ':districtId')); ?>`.replace(':districtId', districtId),
                    method: 'GET',
                    success: function (data) {
                        data.forEach(function (tehsil) {
                            let isSelected = selectedTehsil == tehsil.id ? 'selected' : '';
                            $('#tehsilEdit').append(
                                `<option value="${tehsil.id}" ${isSelected}>${tehsil.name}</option>`
                            );
                        });
                    },
                    error: function (xhr) {
                        console.error('Error fetching tehsils:', xhr);
                    }
                });
            }
        }
    
        // Auto-load tehsils in edit form when the page loads
        let selectedDistrict = "<?php echo e(old('district_name', $InsuranceSubType->district_name ?? '')); ?>"; 
        let selectedTehsil = "<?php echo e(old('tehsil_id', $InsuranceSubType->tehsil_id ?? '')); ?>"; 
    
        if (selectedDistrict) {
            $('#districtEdit').val(selectedDistrict).trigger('change'); // Set district
            loadTehsilsForEdit(selectedDistrict, selectedTehsil); // Load tehsils and set selected one
        }
    
        // Update tehsils when changing district in edit form
        $('#districtEdit').change(function () {
            let districtId = $(this).val();
            loadTehsilsForEdit(districtId);
        });
    });
</script>
    
    

<script>
    document.addEventListener("DOMContentLoaded", function () {
        // Get all filter dropdowns
        let cropFilter = document.getElementById("cropFilter");
        let districtFilter = document.getElementById("districtFilter");
        let tehsilFilter = document.getElementById("tehsilFilter");
        let yearFilter = document.getElementById("yearFilter");
    
        // Get all table rows
        let tableRows = document.querySelectorAll("#table_id_events tbody tr");
    
        function filterTable() {
            let cropValue = cropFilter.value.toLowerCase();
            let districtValue = districtFilter.value.toLowerCase();
            let tehsilValue = tehsilFilter.value.toLowerCase();
            let yearValue = yearFilter.value.toLowerCase();
    
            tableRows.forEach(row => {
                let crop = row.querySelector("td:nth-child(2)").textContent.toLowerCase();
                let district = row.querySelector("td:nth-child(3)").textContent.toLowerCase();
                let tehsil = row.querySelector("td:nth-child(4)").textContent.toLowerCase();
                let year = row.querySelector("td:nth-child(6)").textContent.toLowerCase();
    
                // Check if the row matches all filters
                let matchesCrop = cropValue === "" || crop.includes(cropValue);
                let matchesDistrict = districtValue === "" || district.includes(districtValue);
                let matchesTehsil = tehsilValue === "" || tehsil.includes(tehsilValue);
                let matchesYear = yearValue === "" || year.includes(yearValue);
    
                // Show or hide the row based on matching filters
                if (matchesCrop && matchesDistrict && matchesTehsil && matchesYear) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            });
        }
    
        // Add event listeners to all filters
        cropFilter.addEventListener("change", filterTable);
        districtFilter.addEventListener("change", filterTable);
        tehsilFilter.addEventListener("change", filterTable);
        yearFilter.addEventListener("change", filterTable);
    });
    </script>
    <script>
    // When modal opens, fetch Tehsils and populate
    $('.modal').on('shown.bs.modal', function () {
        let modal = $(this);
        let districtId = modal.data('district-id');
        let tehsilId = modal.data('tehsil-id');
        let modalId = modal.data('id');

        if (districtId) {
            loadTehsils(districtId, modalId, tehsilId);
        }
    });

    // On district change
    $('.district-select').on('change', function () {
        let districtId = $(this).val();
        let modalId = $(this).data('id');
        $('#tehsilEdit-' + modalId).html('<option value="">Loading...</option>');

        if (districtId) {
            loadTehsils(districtId, modalId);
        }
    });

    function loadTehsils(districtId, modalId, selectedTehsilId = null) {
        $.ajax({
            url: '<?php echo e(route("get.tehsils", ":districtId")); ?>'.replace(':districtId', districtId),
            method: 'GET',
            success: function (data) {
                let tehsilDropdown = $('#tehsilEdit-' + modalId);
                tehsilDropdown.empty().append('<option value="">Select Tehsil</option>');

                data.forEach(function (tehsil) {
                    let selected = selectedTehsilId == tehsil.id ? 'selected' : '';
                    tehsilDropdown.append(`<option value="${tehsil.id}" ${selected}>${tehsil.name}</option>`);
                });
            },
            error: function () {
                alert('Failed to load tehsils.');
            }
        });
    }
</script>


    <script>
        $(document).ready(function() {
            $('#table_id_events').DataTable()
        })
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
    <script type="text/javascript">
        $('.show_confirm').click(function(event) {
            var form = $(this).closest("form");
            var name = $(this).data("name");
            event.preventDefault();
            swal({
                    title: `Are you sure you want to delete this record?`,
                    text: "If you delete this, it will be gone forever.",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        form.submit();
                    }
                });
        });
    </script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Crop-Secure-Admin\resources\views/admin/insurance_types_and_sub_types/sub_types.blade.php ENDPATH**/ ?>