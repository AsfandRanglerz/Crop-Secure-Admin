
<?php $__env->startSection('title', 'Insurance Sub-Types'); ?>
<?php $__env->startSection('content'); ?>

    
    <div class="modal fade" id="InsuranceTypesModal" tabindex="-1" role="dialog" aria-labelledby="InsuranceTypesModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add NDVI Insurance</h5>
                    <button type="button" class="close" data-dismiss="modal"
                        aria-label="Close"><span>&times;</span></button>
                </div>
                <form action="<?php echo e(route('insurance.sub.type.satelliteNDVI.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <input type="hidden" name="incurance_type_id" value="<?php echo e($InsuranceType->id); ?>">
                        <div class="row">
                            <div class="col-md-6">
                                <label for="date">Date</label>
                                <input type="date" class="form-control" name="date" required>
                                <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="b8">B8 (NIR)</label>
                                <input type="number" max="999999999999999" step="0.0001" class="form-control"
                                    id="b8" name="b8" required>
                            </div>

                            <div class="col-md-6 mt-3">
                                <label for="b4">B4 (Red)</label>
                                <input type="number" max="999999999999999" step="0.0001" class="form-control"
                                    id="b4" name="b4" required>
                            </div>

                            <div class="col-md-6 mt-3">
                                <label for="ndvi">Calculated NDVI</label>
                                <input type="text" class="form-control" id="ndvi" name="ndvi" readonly>
                            </div>
                        </div>
                        <button type="button" class="btn btn-info btn-sm mt-3" onclick="calculateNDVI()">Calculate
                            NDVI</button>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Create</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div class="main-content">
        <section class="section">
            <div class="section-body">
                <div class="row">
                    <div class="col-12">
                        <a class="btn btn-primary mb-2" href="<?php echo e(route('insurance.type.index')); ?>">Back</a>
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h4 class="mb-0"><?php echo e($InsuranceType->name); ?></h4>
                            </div>

                            <div class="card-body table-striped table-bordered table-responsive">
                                <?php if(Auth::guard('admin')->check() ||
                                        $sideMenuPermissions->contains(fn($permission) => $permission['side_menu_name'] === 'Insurance Types' &&
                                                $permission['permissions']->contains('create'))): ?>
                                    <a class="btn btn-primary mb-3 text-white" href="#" data-toggle="modal"
                                        data-target="#InsuranceTypesModal">Create</a>
                                <?php endif; ?>

                                <table class="table" id="table_id_events">
                                    <thead>
                                        <tr>
                                            <th>Sr.</th>
                                            <th>Date</th>
                                            <th>B4 Value</th>
                                            <th>B8 Value</th>
                                            <th>NDVI</th>
                                            <th>Vegetation Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $InsuranceSubTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $InsuranceSubType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($InsuranceSubType->date ?? '-'); ?></td>
                                                <td><?php echo e($InsuranceSubType->b4 ?? '-'); ?></td>
                                                <td><?php echo e($InsuranceSubType->b8 ?? '-'); ?></td>
                                                <td><?php echo e($InsuranceSubType->ndvi ?? '-'); ?></td>
                                                <td>
                                                    <?php if($InsuranceSubType->ndvi < 0.4): ?>
                                                        <span class="badge badge-danger">Poor</span>
                                                    <?php else: ?>
                                                        <span class="badge badge-success">Healthy</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <div class="d-flex gap-4">
                                                        <?php if(Auth::guard('admin')->check() ||
                                                                $sideMenuPermissions->contains(fn($permission) => $permission['side_menu_name'] === 'Insurance Types' &&
                                                                        $permission['permissions']->contains('delete'))): ?>
                                                            <form
                                                                action="<?php echo e(route('insurance.sub.type.satelliteNDVI.destroy', $InsuranceSubType->id)); ?>"
                                                                method="POST" style="display:inline-block;">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <input type="hidden" name="incurance_type_id"
                                                                    value="<?php echo e($InsuranceType->id); ?>">
                                                                <button type="submit"
                                                                    class="btn btn-sm btn-danger show_subType_confirm">Delete</button>
                                                            </form>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>

    <script>
        $(document).ready(function() {
            // Set min and max date to current year only
            const today = new Date();
            const year = today.getFullYear();
            const minDate = `${year}-01-01`;
            const maxDate = `${year}-12-31`;

            $("input[name='date']").attr("min", minDate);
            $("input[name='date']").attr("max", maxDate);

            $('#table_id_events').DataTable();

            $('.show_subType_confirm').click(function(event) {
                event.preventDefault();
                const form = $(this).closest("form");
                swal({
                    title: `Are you sure you want to delete this record?`,
                    text: "If you delete this, it will be gone forever.",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                }).then((willDelete) => {
                    if (willDelete) {
                        form.submit();
                    }
                });
            });
        });

        function calculateNDVI() {
            const b8 = parseFloat(document.getElementById("b8").value);
            const b4 = parseFloat(document.getElementById("b4").value);

            if (isNaN(b8) || isNaN(b4) || (b8 + b4) === 0) {
                alert("Please enter B8 and B4 values.");
                return;
            }

            const ndvi = (b8 - b4) / (b8 + b4);
            document.getElementById("ndvi").value = ndvi.toFixed(4);
        }

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        // Auto-fetch NDVI data on date change
        $("input[name='date']").on("change", function() {
            const selectedDate = $(this).val();
            const insuranceTypeId = $("input[name='incurance_type_id']").val();

            // console.log("Date changed:", selectedDate);

            if (!selectedDate) return;

            $.ajax({
                url: "<?php echo e(route('ndvi.fetch')); ?>",
                method: "GET",
                data: {
                    date: selectedDate,
                    insurance_type_id: insuranceTypeId
                },
                success: function(response) {
                    console.log("NDVI response:", response);
                    $("#b4").val(response.b4);
                    $("#b8").val(response.b8);
                    $("#ndvi").val(response.ndvi);
                },
                error: function(xhr, status, error) {
                    console.error("NDVI error:", error);
                    console.log("Status:", status);
                    console.log("Response:", xhr.responseText);
                    alert("Failed to fetch NDVI data. Try again.");
                    $("#b4").val('');
                    $("#b8").val('');
                    $("#ndvi").val('');
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Crop-Secure-Admin\resources\views/admin/insurance_types_and_sub_types/sub_types_satelliteNDVI.blade.php ENDPATH**/ ?>