<footer class="main-footer">
    <div class="footer-left">
        <p>Powered By <a href="#">Crop Secure</a></p>
    </div>
    <div class="footer-right">
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\Crop-Secure-Admin\resources\views/admin/common/footer.blade.php ENDPATH**/ ?>