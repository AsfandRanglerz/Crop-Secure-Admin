<p>Your OTP code is: <strong><?php echo e($otp); ?></strong></p>
<?php /**PATH C:\xampp\htdocs\Crop-Secure-Admin\resources\views/emails/otp.blade.php ENDPATH**/ ?>