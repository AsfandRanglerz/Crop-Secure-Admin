
<?php $__env->startSection('title', 'Authorized Dealer Items'); ?>
<?php $__env->startSection('content'); ?>


    <div class="main-content" style="min-height: 562px;">
        <section class="section">
            <a class="btn btn-primary mb-3" href="<?php echo e(route('dealer.index')); ?>">Back</a>
            <div class="section-body">
                <div class="row">
                    <div class="col-12 col-md-12 col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <div class="col-12">
                                    <h4>Dealer Items</h4>
                                </div>
                            </div>
                            <div class="card-body table-striped table-bordered table-responsive">
                                <a class="btn btn-primary mb-3 text-white" href="<?php echo e(route('dealer.item.create', $dealer_id)); ?>">Create</a>
                                <table class="table text-center" id="table_id_events">
                                    <thead>
                                        <tr>
                                            <th>Sr.</th>
                                            <th>Name</th>
                                            <th>Quantity</th>
                                            <th>Price</th>
                                            <th>Status</th>
                                            <th scope="col">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $dealerItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e(ucfirst($items->item->name)); ?></td>
                                                <td><?php echo e(number_format($items->quantity)); ?></td>
                                                <td><?php echo e(number_format($items->price)); ?> PKR</td>
                                                <td>
                                                    <?php if($items->status == 1): ?>
                                                    <div class="badge badge-success badge-shadow">Activated</div>
                                                    <?php else: ?>
                                                    <div class="badge badge-danger badge-shadow">Deactivated</div>
                                                <?php endif; ?>
                                                </td>
                                                <td>
                                                    <div class="d-flex gap-4">
                                                        <a href="
                                                    <?php echo e(route('dealer.item.edit', ['dealer_id' => $dealer_id, 'item_id' => $items->id])); ?>

                                                    "
                                                            class="btn btn-primary" style="margin-left: 10px">Edit</a>
                                                        <form action="<?php echo e(route('dealer.item.destroy', [$items->id])); ?>"
                                                        method="POST"
                                                            style="display:inline-block; margin-left: 10px">
                                                            <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <input type="hidden" name="dealer_id" value="<?php echo e($dealer_id); ?>">
                                                            <button type="submit"
                                                                class="btn btn-danger btn-flat show_confirm"
                                                                data-toggle="tooltip">Delete</button>
                                                        </form>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script>
        $(document).ready(function() {
            $('#table_id_events').DataTable()
        })
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
    <script type="text/javascript">
        $('.show_confirm').click(function(event) {
            var form = $(this).closest("form");
            var name = $(this).data("name");
            event.preventDefault();
            swal({
                    title: `Are you sure you want to delete this record?`,
                    text: "If you delete this, it will be gone forever.",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        form.submit();
                    }
                });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Crop-Secure-Admin\resources\views/admin/authorized_dealer/items/index.blade.php ENDPATH**/ ?>