
<?php $__env->startSection('title', 'Notifications'); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .select2-container {
            display: block;
        }

        .read-more-link {
            color: #007bff;
            cursor: pointer;
            text-decoration: none;
        }

        .read-more-link:hover {
            text-decoration: underline;
        }

        .d-none {
            display: none;
        }

        .toggle-names {
            color: #007bff;
            cursor: pointer;
            text-decoration: none;
            font-size: 0.9em;
            margin-left: 4px;
        }

        .toggle-names:hover {
            text-decoration: underline;
        }

        .d-none {
            display: none;
        }

        .name-preview {
            display: inline-block;
            margin-right: 5px;
        }
    </style>


    <div class="modal fade" id="notificationModal" tabindex="-1" role="dialog" aria-labelledby="notificationModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form action="<?php echo e(route('notification.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Send Notification</h5>
                        <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                    </div>
                    <div class="modal-body">
                        

                        <div class="form-group" id="farmers-group">
                            <label for="farmers">Select Farmers</label>
                            <div>
                                <input type="checkbox" id="selectAllFarmers">
                                <label for="selectAllFarmers">Select All</label>
                            </div>
                            <select class="form-control" id="farmers" name="farmers[]" multiple>
                                <?php $__currentLoopData = $farmers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $farmer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($farmer->id); ?>"><?php echo e($farmer->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="edit_title">Title</label>
                            <input type="text" class="form-control" id="edit_title" name="title" required>
                        </div>


                        <div class="form-group">
                            <label for="message">Message</label>
                            <textarea name="message" class="form-control" rows="5" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button class="btn btn-primary">Send Notification</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="main-content">
        <section class="section">
            <div class="card">
                <div class="card-header">
                    <h4>Notifications</h4>
                </div>
                <div class="card-body table-responsive">
                    <?php if(Auth::guard('admin')->check() ||
                            $sideMenuPermissions->contains(fn($p) => $p['side_menu_name'] === 'Notifications' && $p['permissions']->contains('create'))): ?>
                        <a class="btn btn-primary mb-3 text-white" data-toggle="modal"
                            data-target="#notificationModal">Create</a>
                    <?php endif; ?>

                    <table class="table table-bordered text-center" id="table_id_events">
                        <thead>
                            <tr>
                                <th>Sr.</th>
                                <th>Name</th>
                                <th>Title</th>
                                <th>Message</th>
                                
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td>
                                        <?php
                                            $names = [];
                                            foreach ($notification->targets as $target) {
                                                if (
                                                    $target->targetable_type === \App\Models\Farmer::class &&
                                                    isset($farmers[$target->targetable_id])
                                                ) {
                                                    $names[] = $farmers[$target->targetable_id]->name;
                                                }
                                            }

                                            $totalNames = count($names);
                                            $displayNames = array_slice($names, 0, 2); // Show first 2 names by default
                                        ?>

                                        <?php $__currentLoopData = $displayNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="name-preview"><?php echo e($name); ?></span><br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php if($totalNames > 2): ?>
                                            <span class="additional-names d-none">
                                                <?php $__currentLoopData = array_slice($names, 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($name); ?><br>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </span>
                                            <a href="#" class="toggle-names" data-count="<?php echo e($totalNames - 2); ?>">
                                                <?php echo e($totalNames - 2); ?>+
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($notification->title); ?></td>
                                    <td>
                                        <?php
                                            $words = explode(' ', $notification->message);
                                            $shortMessage = implode(' ', array_slice($words, 0, 3));
                                            $showReadMore = count($words) > 3;
                                        ?>

                                        <span class="message-preview"><?php echo e($shortMessage); ?></span>
                                        <?php if($showReadMore): ?>
                                            <span class="full-message d-none"><?php echo e($notification->message); ?></span>
                                            <a href="#" class="read-more-link">... Read More</a>
                                        <?php endif; ?>
                                    </td>
                                    

                                    <td>
                                        <button class="btn btn-sm btn-primary editBtn" data-id="<?php echo e($notification->id); ?>"
                                            data-message="<?php echo e($notification->message); ?>"
                                            data-user-type="<?php echo e(json_encode($notification->user_type)); ?>"
                                            data-farmers="<?php echo e(json_encode($notification->targets->where('targetable_type', \App\Models\Farmer::class)->pluck('targetable_id')->toArray())); ?>">
                                            Edit
                                        </button>

                                        <form action="<?php echo e(route('notification.destroy', $notification->id)); ?>"
                                            method="POST" class="deleteForm d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="button"
                                                class="btn btn-sm btn-danger show_confirm">Delete</button>
                                        </form>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
    </div>

    <!-- Edit Modal -->
    <div class="modal fade" id="editNotificationModal" tabindex="-1" role="dialog"
        aria-labelledby="editNotificationModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form id="editNotificationForm" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Notification</h5>
                        <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                    </div>

                    <div class="modal-body">
                        <input type="hidden" name="notification_id" id="edit_notification_id">

                        

                        <div class="form-group">
                            <label for="edit_farmers">Select Farmers</label>
                            <div>
                                <input type="checkbox" id="edit_selectAllFarmers">
                                <label for="edit_selectAllFarmers">Select All</label>
                            </div>
                            <select class="form-control" id="edit_farmers" name="farmers[]" multiple>
                                <?php $__currentLoopData = $farmers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $farmer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($farmer->id); ?>"
                                        <?php echo e(isset($selectedFarmerIds) && in_array($farmer->id, $selectedFarmerIds) ? 'selected' : ''); ?>>
                                        <?php echo e($farmer->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
    <label for="edit_title">Title</label>
    <input type="text" class="form-control" id="edit_title" name="title" required>
</div>

                        <div class="form-group">
                            <label for="edit_message">Message</label>
                            <textarea name="message" class="form-control" id="edit_message" rows="5" required></textarea>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button class="btn btn-primary">Update Notification</button>
                    </div>
                </div>
            </form>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
    <script type="text/javascript">
        $('.show_confirm').click(function(event) {
            var form = $(this).closest("form");
            var name = $(this).data("name");
            event.preventDefault();
            swal({
                    title: `Are you sure you want to delete this record?`,
                    text: "If you delete this, it will be gone forever.",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        form.submit();
                    }
                });
        });
    </script>

    
    <script>
        $(document).ready(function() {
            // Initialize select2 dropdown
            $('#farmers, #edit_farmers').select2({
                placeholder: 'Select Farmers',
                allowClear: true
            });

            $('#table_id_events').DataTable();

            // Select all farmers
            $('#selectAllFarmers').change(function() {
                $('#farmers option').prop('selected', this.checked).trigger('change');
            });

            $('#edit_selectAllFarmers').change(function() {
                $('#edit_farmers option').prop('selected', this.checked).trigger('change');
            });

            // Edit button logic (updated only for farmers)
            $('.editBtn').on('click', function() {
                const id = $(this).data('id');
                const message = $(this).data('message');
                const farmers = $(this).data('farmers');
                const title = $(this).data('title');

                $('#edit_notification_id').val(id);
                $('#edit_message').val(message);
                $('#edit_title').val(title);

                if (farmers && farmers.length > 0) {
                    $('#edit_farmers').val(farmers).trigger('change');
                } else {
                    $('#edit_farmers').val(null).trigger('change');
                }

                $('#edit_selectAllFarmers').prop('checked', $('#edit_farmers option').length === $(
                    '#edit_farmers option:selected').length);

                $('#editNotificationForm').attr('action', '<?php echo e(route('notification.update', '')); ?>/' + id);
                $('#editNotificationModal').modal('show');
            });

            // Read more toggle
            $(document).on('click', '.read-more-link', function(e) {
                e.preventDefault();
                const $parent = $(this).parent();
                $parent.find('.message-preview').addClass('d-none');
                $parent.find('.full-message').removeClass('d-none');
                $(this).remove(); // Remove "Read More" link
            });

            // Show more/less names
            $(document).on('click', '.toggle-names', function(e) {
                e.preventDefault();
                const $this = $(this);
                const $additionalNames = $this.prev('.additional-names');
                const count = $this.data('count');

                if ($additionalNames.hasClass('d-none')) {
                    $additionalNames.removeClass('d-none');
                    $this.text('Show less');
                } else {
                    $additionalNames.addClass('d-none');
                    $this.text(count + '+');
                }
            });

            // Toastr notifications
            <?php if(session('success')): ?>
                toastr.success(<?php echo json_encode(session('success'), 15, 512) ?>);
            <?php endif; ?>

            <?php if(session('error')): ?>
                toastr.error(<?php echo json_encode(session('error'), 15, 512) ?>);
            <?php endif; ?>

            <?php if(session('info')): ?>
                toastr.info(<?php echo json_encode(session('info'), 15, 512) ?>);
            <?php endif; ?>
        });
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Crop-Secure-Admin\resources\views/admin/notification/index.blade.php ENDPATH**/ ?>