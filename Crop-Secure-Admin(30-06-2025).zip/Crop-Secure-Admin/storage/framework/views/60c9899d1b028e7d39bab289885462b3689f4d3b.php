
<?php $__env->startSection('title', 'Insurance Sub-Types'); ?>
<?php $__env->startSection('content'); ?>



    
    <div class="modal fade" id="InsuranceTypesModal" tabindex="-1" role="dialog" aria-labelledby="InsuranceTypesModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="InsuranceTypesModalLabel">Add</h5>
                    
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('insurance.sub.type.productionPrice.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <input type="hidden" name="incurance_type_id" value="<?php echo e($InsuranceType->id); ?>">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="crop_name_id">Crop</label>
                                    <select name="crop_name_id" class="form-control">
                                        <option value="">Select Crop</option>
                                        <?php $__currentLoopData = $ensuredCrops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($crop->id); ?>"><?php echo e($crop->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="year">Year</label>
                                    <input type="text" name="year" class="form-control"
                                        value="<?php echo e(old('year', now()->year)); ?>" readonly>
                                    <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="district">District</label>
                                    <select name="crops[0][district_id]" class="form-control district-select" required>
                                        <option value="">Select District</option>
                                        <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($district->id); ?>"><?php echo e($district->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['crops.0.district_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Tehsil -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="tehsil">Tehsil</label>
                                    <select name="crops[0][tehsil_id]" class="form-control tehsil-select" required>
                                        <option value="">Select Tehsil</option>
                                    </select>
                                    <?php $__errorArgs = ['crops.0.tehsil_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="cost_of_production">Cost of Production</label>
                                    <div class="input-group">
                                        <input type="number" name="crops[0][cost_of_production]" class="form-control"
                                            value="<?php echo e(old('cost_of_production')); ?>">
                                        <div class="input-group-append">
                                            <span class="input-group-text font-weight-bold"
                                                style="border: 1px solid #cbd2d8;">PKR</span>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['cost_of_production'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="average_yield">Average yield</label>
                                    <div class="input-group">
                                        <input type="number" name="crops[0][average_yield]" class="form-control"
                                            value="<?php echo e(old('average_yield')); ?>">
                                        <div class="input-group-append">
                                            <span class="input-group-text font-weight-bold"
                                                style="border: 1px solid #cbd2d8;">%</span>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['average_yield'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="current_yield">Historical Average Market Price</label>
                                    <div class="input-group">
                                        <input type="number" name="crops[0][historical_average_market_price]"
                                            class="form-control" value="<?php echo e(old('historical_average_market_price')); ?>">
                                        <div class="input-group-append">
                                            <span class="input-group-text font-weight-bold"
                                                style="border: 1px solid #cbd2d8;">PKR</span>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['historical_average_market_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="current_yield">Real-time Market Price (AMP)</label>
                                    <div class="input-group">
                                        <input type="number" name="crops[0][real_time_market_price]" class="form-control"
                                            value="<?php echo e(old('real_time_market_price')); ?>">
                                        <div class="input-group-append">
                                            <span class="input-group-text font-weight-bold"
                                                style="border: 1px solid #cbd2d8;">PKR</span>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['real_time_market_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="current_yield">Insured Yield</label>
                                    <div class="input-group">
                                        <input type="number" name="crops[0][ensured_yield]" class="form-control"
                                            value="<?php echo e(old('ensured_yield')); ?>">
                                        <div class="input-group-append">
                                            <span class="input-group-text font-weight-bold"
                                                style="border: 1px solid #cbd2d8;">%</span>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['ensured_yield'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div id="productionFieldsWrapper"></div>
                        <button type="button" id="addCropRow" class="btn btn-sm btn-info">Add More</button>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Create</button>
                    </div>
                </form>
            </div>
        </div>
    </div>



    
    <?php $__currentLoopData = $InsuranceSubTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $InsuranceSubType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="EditInsuranceTypesModal-<?php echo e($InsuranceSubType->id); ?>" tabindex="-1" role="dialog"
            aria-labelledby="EditInsuranceTypesModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="EditInsuranceTypesModalLabel">Edit </h5>
                        
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form action="<?php echo e(route('insurance.sub.type.productionPrice.update', $InsuranceSubType->id)); ?>"
                        method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <div class="modal-body">
                            <div class="row">
                                <input type="hidden" name="incurance_type_id" value="<?php echo e($InsuranceType->id); ?>">

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="crop_name_id">Crop</label>
                                        <select name="crop_name_id" class="form-control" required>
                                            <option value="">Select Crop</option>
                                            <?php $__currentLoopData = $ensuredCrops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($crop->id); ?>"
                                                    <?php echo e(old('crop_name_id', $InsuranceSubType->crop_name_id) == $crop->id ? 'selected' : ''); ?>>
                                                    <?php echo e($crop->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['crop_name_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <!-- District Dropdown -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="district">District</label>
                                        <select name="crops[0][district_id]" class="form-control district-select"
                                            required>
                                            <option value="">Select District</option>
                                            <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($district->id); ?>"
                                                    <?php echo e(old('crops.0.district_id', $InsuranceSubType->district_id) == $district->id ? 'selected' : ''); ?>>
                                                    <?php echo e($district->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['crops.0.district_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <!-- Tehsil Dropdown -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="tehsil">Tehsil</label>
                                        <select name="crops[0][tehsil_id]" class="form-control tehsil-select"
                                            data-selected="<?php echo e(old('crops.0.tehsil_id', $InsuranceSubType->tehsil_id)); ?>"
                                            required>
                                            <option value="">Select Tehsil</option>
                                            
                                        </select>
                                        <?php $__errorArgs = ['crops.0.tehsil_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="cost_of_production">Cost of Production</label>
                                        <input type="text" name="cost_of_production" class="form-control"
                                            value="<?php echo e(old('cost_of_production', $InsuranceSubType->cost_of_production)); ?>">
                                        <?php $__errorArgs = ['cost_of_production'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="average_yield">Average Yield</label>
                                        <input type="text" name="average_yield" class="form-control"
                                            value="<?php echo e(old('average_yield', $InsuranceSubType->average_yield)); ?>">
                                        <?php $__errorArgs = ['average_yield'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="historical_average_market_price">Historical Average Market
                                            Price</label>
                                        <input type="text" name="historical_average_market_price" class="form-control"
                                            value="<?php echo e(old('historical_average_market_price', $InsuranceSubType->historical_average_market_price)); ?>">
                                        <?php $__errorArgs = ['historical_average_market_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="real_time_market_price">Real-time Market Price (AMP)</label>
                                        <input type="text" name="real_time_market_price" class="form-control"
                                            value="<?php echo e(old('real_time_market_price', $InsuranceSubType->real_time_market_price)); ?>">
                                        <?php $__errorArgs = ['real_time_market_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ensured_yield">Insured Yield (IY)</label>
                                        <input type="text" name="ensured_yield" class="form-control"
                                            value="<?php echo e(old('ensured_yield', $InsuranceSubType->ensured_yield)); ?>">
                                        <?php $__errorArgs = ['ensured_yield'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="year">Year</label>
                                        <input type="text" name="year" class="form-control"
                                            value="<?php echo e(old('year', $InsuranceSubType->year)); ?>" readonly>
                                        <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





    <div class="main-content" style="min-height: 562px;">
        <section class="section">
            <div class="section-body">
                <div class="row">
                    <div class="col-12 col-md-12 col-lg-12">
                        <a class="btn btn-primary mb-2" href="<?php echo e(route('insurance.type.index')); ?>">Back</a>
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h4 class="mb-0"><?php echo e($InsuranceType->name); ?></h4>

                                <div class="d-flex gap-5">
                                    <select id="cropFilter" class="form-control form-select w-auto rounded mr-2">
                                        <option value="">Crops</option>
                                        <?php $__currentLoopData = $InsuranceSubTypes->unique('crop_name_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e(strtolower($subtype->crop->name ?? '')); ?>">
                                                <?php echo e($subtype->crop->name ?? 'Unknown Crop'); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <select id="districtFilter" class="form-control form-select w-auto rounded mr-2">
                                        <option value="">Districts</option>
                                        <?php $__currentLoopData = $InsuranceSubTypes->pluck('district.name')->unique(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($district); ?>"><?php echo e($district); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <select id="tehsilFilter" class="form-control form-select w-auto rounded mr-2">
                                        <option value="">Tehsil</option>
                                        <?php $__currentLoopData = $InsuranceSubTypes->pluck('tehsil.name')->unique(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tehsil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tehsil); ?>"><?php echo e($tehsil); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <select id="yearFilter" class="form-control form-select w-auto rounded mr-2">
                                        <option value="">Year</option>
                                        <?php $__currentLoopData = $InsuranceSubTypes->pluck('year')->unique(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="card-body table-striped table-bordered table-responsive">
                                <?php if(Auth::guard('admin')->check() ||
                                        $sideMenuPermissions->contains(fn($permission) => $permission['side_menu_name'] === 'Insurance Types' &&
                                                $permission['permissions']->contains('create'))): ?>
                                    <a class="btn btn-primary mb-3 text-white" href="#" data-toggle="modal"
                                        data-target="#InsuranceTypesModal">Create</a>
                                <?php endif; ?>

                                <table class="table responsive" id="table_id_events">
                                    <thead>
                                        <tr>
                                            <th>Sr.</th>
                                            <th>Crop</th>
                                            <th>District</th>
                                            <th>Tehsil</th>
                                            <th>Cost of Production</th>
                                            <th>Average Yield</th>
                                            <th>Historical Average Market Price</th>
                                            <th>Real-time Market Price (AMP)</th>
                                            <th>Insured Yield (IY)</th>
                                            <th>Year</th>
                                            <th scope="col">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $InsuranceSubTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $InsuranceSubType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($InsuranceSubType->crop->name ?? 'N/A'); ?></td>
                                                <td class="district">
                                                    <?php echo e($InsuranceSubType->district->name ?? 'No district'); ?></td>
                                                <td class="tehsil"><?php echo e($InsuranceSubType->tehsil->name ?? 'No tehsil'); ?>

                                                </td>
                                                <td><?php echo e($InsuranceSubType->cost_of_production); ?> PKR</td>
                                                <td><?php echo e($InsuranceSubType->average_yield); ?>%</td>
                                                <td><?php echo e($InsuranceSubType->historical_average_market_price); ?> PKR</td>
                                                <td><?php echo e($InsuranceSubType->real_time_market_price); ?> PKR</td>
                                                <td><?php echo e($InsuranceSubType->ensured_yield); ?>%</td>
                                                <td class="year"><?php echo e($InsuranceSubType->year); ?></td>
                                                <td>
                                                    <div class="d-flex gap-4">
                                                        <?php if(Auth::guard('admin')->check() ||
                                                                $sideMenuPermissions->contains(fn($permission) => $permission['side_menu_name'] === 'Insurance Types' &&
                                                                        $permission['permissions']->contains('edit'))): ?>
                                                            <a class="btn btn-primary text-white" href="#"
                                                                data-toggle="modal"
                                                                data-target="#EditInsuranceTypesModal-<?php echo e($InsuranceSubType->id); ?>">Edit</a>
                                                        <?php endif; ?>

                                                        <!-- Delete Button -->
                                                        <?php if(Auth::guard('admin')->check() ||
                                                                $sideMenuPermissions->contains(fn($permission) => $permission['side_menu_name'] === 'Insurance Types' &&
                                                                        $permission['permissions']->contains('delete'))): ?>
                                                            <form
                                                                action="
                                                        <?php echo e(route('insurance.sub.type.productionPrice.destroy', $InsuranceSubType->id)); ?>

                                                            "
                                                                method="POST"
                                                                style="display:inline-block; margin-left: 10px">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <input type="hidden" name="incurance_type_id"
                                                                    value="<?php echo e($InsuranceType->id); ?>">
                                                                <button type="submit"
                                                                    class="btn btn-danger btn-flat show_subType_confirm"
                                                                    data-toggle="tooltip">Delete</button>
                                                            </form>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {
            /** ========== ADD FORM HANDLING ========== */
            $(document).on('change', '.district-select', function() {
                let $district = $(this);
                loadTehsils($district);
                // let districtId = $(this).val();
                // let $tehsilSelect = $(this).closest('.row').find('.tehsil-select');

                $tehsilSelect.empty().append('<option value="">Select Tehsil</option>');

                if (districtId) {
                    $.ajax({
                        url: `<?php echo e(route('get.tehsils', ':districtId')); ?>`.replace(':districtId',
                            districtId),
                        method: 'GET',
                        success: function(data) {
                            data.forEach(function(tehsil) {
                                $tehsilSelect.append(
                                    `<option value="${tehsil.id}">${tehsil.name}</option>`
                                );
                            });
                        },
                        error: function(xhr) {
                            console.error('Error fetching tehsils:', xhr);
                        }
                    });
                }
            });

            /** ========== EDIT FORM HANDLING ========== */
            function loadTehsils($districtSelect, selectedTehsil = null) {
                let districtId = $districtSelect.val();
                let $row = $districtSelect.closest('.row');
                let $tehsilSelect = $row.find('.tehsil-select');

                $tehsilSelect.empty().append('<option value="">Select Tehsil</option>');

                if (districtId) {
                    $.ajax({
                        url: `<?php echo e(route('get.tehsils', ':districtId')); ?>`.replace(':districtId',
                            districtId),
                        method: 'GET',
                        success: function(data) {
                            data.forEach(function(tehsil) {
                                let isSelected = selectedTehsil == tehsil.id ? 'selected' : '';
                                $tehsilSelect.append(
                                    `<option value="${tehsil.id}" ${isSelected}>${tehsil.name}</option>`
                                );
                            });
                        },
                        error: function(xhr) {
                            console.error('Error fetching tehsils:', xhr);
                        }
                    });
                }
            }

            // Handle district change for all district dropdowns
            $(document).on('change', '.district-select', function() {
                let $district = $(this);
                loadTehsils($district);
            });

            // On page load, load tehsils for all pre-filled district fields (edit case)
            $('.district-select').each(function() {
                let $district = $(this);
                let selectedTehsil = $district.data('selected-tehsil') || $district.closest('.row').find(
                    '.tehsil-select').data('selected');
                if ($district.val()) {
                    loadTehsils($district, selectedTehsil);
                }
            });
        });
    </script>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Get all filter dropdowns
            let cropFilter = document.getElementById("cropFilter");
            let districtFilter = document.getElementById("districtFilter");
            let tehsilFilter = document.getElementById("tehsilFilter");
            let yearFilter = document.getElementById("yearFilter");

            // Get all table rows
            let tableRows = document.querySelectorAll("#table_id_events tbody tr");

            function filterTable() {
                let cropValue = cropFilter.value.toLowerCase();
                let districtValue = districtFilter.value.toLowerCase();
                let tehsilValue = tehsilFilter.value.toLowerCase();
                let yearValue = yearFilter.value.toLowerCase();

                tableRows.forEach(row => {
                    let crop = row.querySelector("td:nth-child(2)").textContent.toLowerCase();
                    let district = row.querySelector("td:nth-child(3)").textContent.toLowerCase();
                    let tehsil = row.querySelector("td:nth-child(4)").textContent.toLowerCase();
                    let year = row.querySelector("td:nth-child(10)").textContent.toLowerCase();

                    // Check if the row matches all filters
                    let matchesCrop = cropValue === "" || crop.includes(cropValue);
                    let matchesDistrict = districtValue === "" || district.includes(districtValue);
                    let matchesTehsil = tehsilValue === "" || tehsil.includes(tehsilValue);
                    let matchesYear = yearValue === "" || year.includes(yearValue);

                    // Show or hide the row based on matching filters
                    if (matchesCrop && matchesDistrict && matchesTehsil && matchesYear) {
                        row.style.display = "";
                    } else {
                        row.style.display = "none";
                    }
                });
            }

            // Add event listeners to all filters
            cropFilter.addEventListener("change", filterTable);
            districtFilter.addEventListener("change", filterTable);
            tehsilFilter.addEventListener("change", filterTable);
            yearFilter.addEventListener("change", filterTable);
        });
    </script>

    <script>
        $(document).ready(function() {
            $('#table_id_events').DataTable()
        })
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
    <script type="text/javascript">
        $('.show_subType_confirm').click(function(event) {
            var form = $(this).closest("form");
            var name = $(this).data("name");
            event.preventDefault();
            swal({
                    title: `Are you sure you want to delete this record?`,
                    text: "If you delete this, it will be gone forever.",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        form.submit();
                    }
                });
        });
    </script>

    <script>
        let productionIndex = 1;

        $('#addCropRow').click(function() {
            const newFields = `
            <div class="crop-field-group row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>District</label>
                        <select class="form-control form-select district-select" name="crops[${productionIndex}][district_id]">
                            <option value="">Select District</option>
                            <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($district->id); ?>"><?php echo e($district->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label>Tehsil</label>
                        <select class="form-control form-select tehsil-select" name="crops[${productionIndex}][tehsil_id]">
                            <option value="">Select Tehsil</option>
                        </select>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="cost_of_production">Cost of Production</label>
                       <div class="input-group">
                            <input type="number" name="crops[${productionIndex}][cost_of_production]" class="form-control" step="0.01">
                            <div class="input-group-append">
                                <span class="input-group-text font-weight-bold" style="border: 1px solid #cbd2d8;">PKR</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="average_yield">Average Yield</label>
                        <div class="input-group">
                            <input type="number" name="crops[${productionIndex}][average_yield]" class="form-control" step="0.01">
                            <div class="input-group-append">
                                <span class="input-group-text font-weight-bold" style="border: 1px solid #cbd2d8;">%</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="historical_average_market_price">Historical Average Market Price</label>
                       <div class="input-group">
                            <input type="number" name="crops[${productionIndex}][historical_average_market_price]" class="form-control" step="0.01">
                            <div class="input-group-append">
                                <span class="input-group-text font-weight-bold" style="border: 1px solid #cbd2d8;">PKR</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="real_time_market_price">Real-time Market Price (AMP)</label>
                        <div class="input-group">
                            <input type="number" name="crops[${productionIndex}][real_time_market_price]" class="form-control" step="0.01">
                            <div class="input-group-append">
                                <span class="input-group-text font-weight-bold" style="border: 1px solid #cbd2d8;">PKR</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="ensured_yield">Insured Yield (IY)</label>
                        <div class="input-group">
                            <input type="number" name="crops[${productionIndex}][ensured_yield]" class="form-control" step="0.01">
                            <div class="input-group-append">
                                <span class="input-group-text font-weight-bold" style="border: 1px solid #cbd2d8;">%</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
            $('#productionFieldsWrapper').append(newFields);
            productionIndex++;
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Crop-Secure-Admin\resources\views/admin/insurance_types_and_sub_types/sub_types_production_price.blade.php ENDPATH**/ ?>