<div class="main-sidebar sidebar-style-2">
    <aside" id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="<?php echo e(url('/admin/dashboard')); ?>">
                <img alt="image" src="<?php echo e(asset('public/admin/assets/img/logo.png')); ?>" class="header-logo" />
                
            </a>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-header">Main</li>
            <li class="dropdown <?php echo e(request()->is('admin/dashboard') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('/admin/dashboard')); ?>" class="nav-link"><i
                        data-feather="home"></i><span>Dashboard</span></a>
            </li>

            <?php if(Auth::guard('admin')->check()): ?>
                
                <li class="dropdown <?php echo e(request()->is('admin/subadmin*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('subadmin.index')); ?>" class="nav-link"><i data-feather="user-check"></i><span>Sub
                            Admins</span></a>
                </li>
            <?php endif; ?>

            <?php if(Auth::guard('admin')->check() || $sideMenuName->contains('Authorized Dealers')): ?>
                
                <li class="dropdown <?php echo e(request()->is('admin/dealer*') ? 'active' : ''); ?>">
                    <a href="
                        <?php echo e(route('dealer.index')); ?>

                        "
                        class="nav-link">
                        <i data-feather="shopping-bag"></i><span> Authorized Dealers</span>
                    </a>
                </li>
            <?php endif; ?>

            <?php if(Auth::guard('admin')->check() || $sideMenuName->contains('Dealer Items')): ?>
                
                <li class="dropdown <?php echo e(request()->is('admin/items*') ? 'active' : ''); ?>">
                    <a href="
                        <?php echo e(route('items.index')); ?>

                        "
                        class="nav-link">
                        <i data-feather="layers"></i><span> Dealer Items</span>
                    </a>
                </li>
            <?php endif; ?>

            <?php if(Auth::guard('admin')->check() || $sideMenuName->contains('Farmers')): ?>
                
                <li class="dropdown <?php echo e(request()->is('admin/farmer*') ? 'active' : ''); ?>">
                    <a href="
                <?php echo e(route('farmers.index')); ?>

                " class="nav-link">
                        <i data-feather="user"></i><span>Farmers</span>
                    </a>
                </li>
            <?php endif; ?>

            <?php if(Auth::guard('admin')->check() || $sideMenuName->contains('Insured Crops')): ?>
                <li
                    class="dropdown <?php echo e(request()->is('admin/ensured-crop-name*') || request()->is('admin/crop-type*') ? 'active' : ''); ?>">
                    <a href="
                <?php echo e(route('ensured.crop.name.index')); ?>

                "
                        class="nav-link  px-2">
                        <i class="fas fa-leaf"></i><span> Insured Crops</span>
                    </a>
                </li>
            <?php endif; ?>

            <?php if(Auth::guard('admin')->check() || $sideMenuName->contains('Land Data Management')): ?>
                
                <li
                    class="dropdown <?php echo e(request()->is('admin/land-data-management*') || request()->is('admin/village*') || request()->is('admin/union*') || request()->is('admin/tehsil*') || request()->is('admin/unit*') ? 'active' : ''); ?>">
                    <a href="
                <?php echo e(route('land.index')); ?>

                " class="nav-link">
                        <i data-feather="map"></i><span>Land Data Management</span>
                    </a>
                </li>
            <?php endif; ?>

            <?php if(Auth::guard('admin')->check() || $sideMenuName->contains('Insurance Companies')): ?>
                
                <li
                    class="dropdown <?php echo e(request()->is('admin/insurance-company*') || request()->is('admin/company-insurance*') ? 'active' : ''); ?>">
                    <a href="
                <?php echo e(route('insurance.company.index')); ?>

                "
                        class="nav-link px-2">
                        <i class="fas fa-shield-alt"></i> <span>Insurance Companies</span>
                    </a>
                </li>
            <?php endif; ?>

            
            <?php if(Auth::guard('admin')->check() || $sideMenuName->contains('Insurance Types')): ?>
                <li
                    class="dropdown <?php echo e(request()->is('admin/insurance-type*') || request()->is('admin/insurance-sub-type*') ? 'active' : ''); ?>">
                    <a href="
                <?php echo e(route('insurance.type.index')); ?>

                "
                        class="nav-link px-2">
                        <i class="fas fa-cogs"></i> <span>Insurance Types</span>
                    </a>
                </li>
            <?php endif; ?>

            <?php
                $newProductClaimCount = \App\Models\InsuranceProductClaim::where('is_seen', false)->count();
            ?>

            <?php if(Auth::guard('admin')->check() || $sideMenuName->contains('Claim Product Purchase')): ?>
                <li class="dropdown <?php echo e(request()->is('admin/insurance-product-claims*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('insurance.product.claims.index')); ?>"
                        class="nav-link px-2 d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-box-open me-2"></i>
                            <span>Claim Product Purchases</span>
                        </div>
                        <?php if($newProductClaimCount > 0): ?>
                            <span
                                class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center"
                                style="width: 22px; height: 22px; font-size: 12px;"
                                title="<?php echo e($newProductClaimCount); ?> pending">
                                <?php echo e($newProductClaimCount); ?>

                            </span>
                        <?php endif; ?>
                    </a>
                </li>
            <?php endif; ?>


            <?php
                $showInsuranceClaimRequests =
                    Auth::guard('admin')->check() || $sideMenuName->contains('Insurance Claim Requests');
                $onClaimPage = request()->is('admin/insurance-claim*');
                $newClaimCount = 0;

                if ($showInsuranceClaimRequests && !$onClaimPage) {
                    $newClaimCount = \App\Models\InsuranceHistory::whereNotNull('claimed_at')
                        ->where(function ($q) {
                            $q->where('is_claim_seen', 0)->orWhereNull('is_claim_seen');
                        })
                        ->where('status', 'pending')
                        ->count();
                }
            ?>

            <?php if($showInsuranceClaimRequests): ?>
                <li class="dropdown <?php echo e($onClaimPage ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('insurance.claim.index')); ?>"
                        class="nav-link px-2 d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-file-alt me-2"></i>
                            <span>Insurance Claim Requests</span>
                        </div>
                        <?php if($newClaimCount > 0): ?>
                            <span
                                class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center"
                                style="width: 22px; height: 22px; font-size: 12px;" title="<?php echo e($newClaimCount); ?> new">
                                <?php echo e($newClaimCount); ?>

                            </span>
                        <?php endif; ?>
                    </a>
                </li>
            <?php endif; ?>


            
            <?php
                $showInsuranceHistory = Auth::guard('admin')->check() || $sideMenuName->contains('Insurance History');
                $onInsurancePage = request()->is('admin/insurance-history*');
                $newInsuranceCount = 0;

                if ($showInsuranceHistory && !$onInsurancePage) {
                    $newInsuranceCount = \App\Models\InsuranceHistory::where(function ($query) {
                        $query->where('is_seen', 0)->orWhereNull('is_seen');
                    })->count();
                }
            ?>

            <?php if($showInsuranceHistory): ?>
                <li class="dropdown <?php echo e($onInsurancePage ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('insurance.history.index')); ?>"
                        class="nav-link px-2 d-flex align-items-center justify-content-between">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-user-shield me-2"></i>
                            <span>Insurance History</span>
                        </div>
                        <?php if($newInsuranceCount > 0): ?>
                            <span
                                class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center"
                                style="width: 22px; height: 22px; font-size: 12px;"
                                title="<?php echo e($newInsuranceCount); ?> new">
                                <?php echo e($newInsuranceCount); ?>

                            </span>
                        <?php endif; ?>
                    </a>
                </li>
            <?php endif; ?>


            <?php if(Auth::guard('admin')->check() || $sideMenuName->contains('Notifications')): ?>
                
                <li class="dropdown <?php echo e(request()->is('admin/notification*') ? 'active' : ''); ?>">
                    <a href="
                <?php echo e(route('notification.index')); ?>

                " class="nav-link">
                        <i data-feather="bell"></i><span>Notifications</span>
                    </a>
                </li>
            <?php endif; ?>

            <?php if(Auth::guard('admin')->check() || $sideMenuName->contains('faqs')): ?>
                <!-- Terms & Conditions Section -->
                <li
                    class="dropdown <?php echo e(request()->is(['admin/faqs', 'admin/contact-us-createview']) ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('admin/faqs')); ?>" class="nav-link">
                        <i data-feather="help-circle"></i><span>FAQ's</span>
                    </a>
                </li>
            <?php endif; ?>

            <?php if(Auth::guard('admin')->check() || $sideMenuName->contains('ContactUs')): ?>
                <!-- Terms & Conditions Section -->
                <li
                    class="dropdown <?php echo e(request()->is(['admin/contact-us', 'admin/contact-us-createview']) ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('admin/contact-us')); ?>" class="nav-link">
                        <i data-feather="mail"></i><span>Contact Us</span>
                    </a>
                </li>
            <?php endif; ?>


            <li class="dropdown <?php echo e(request()->is('admin/about-us*') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('/admin/about-us')); ?>" class="nav-link"><i data-feather="info"></i><span>About
                        Us</span></a>
            </li>
            <li class="dropdown <?php echo e(request()->is('admin/privacy-policy*') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('/admin/privacy-policy')); ?>" class="nav-link"><i
                        data-feather="file-text"></i><span>Privacy policy</span></a>
            </li>
            <li class="dropdown <?php echo e(request()->is('admin/term-condition*') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('/admin/term-condition')); ?>" class="nav-link"><i
                        data-feather="clipboard"></i><span>Terms & Conditions</span></a>
            </li>
        </ul>
        </aside>
</div>
<?php /**PATH C:\xampp\htdocs\Crop-Secure-Admin\resources\views/admin/common/side_menu.blade.php ENDPATH**/ ?>