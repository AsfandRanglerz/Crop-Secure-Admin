
<?php $__env->startSection('title', 'Company Insurance Types'); ?>
<?php $__env->startSection('content'); ?>

    <style>
        .select2-container {
            display: block;
        }
    </style>

    
    <div class="modal fade" id="InsuranceTypesModal" tabindex="-1" role="dialog" aria-labelledby="InsuranceTypesModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="InsuranceTypesModalLabel">Add Insurance Type</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('company.insurance.types.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <input type="hidden" name="insurance_company_id" value="<?php echo e($Company->id); ?>">
                        <div class="row" id="type">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="insurance_type_id">Types</label>
                                    <select name="insurance_type_id[]" id="insurance_type_id" class="form-control" required>
                                        <?php $__currentLoopData = $Insurance_types->whereIn('name', ['Area Yield Index', 'Production Price Index', 'Weather Index', 'Satellite Index (NDVI)']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Insurance_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($Insurance_type->id); ?>"><?php echo e($Insurance_type->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['insurance_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <!-- Crop Selection for Weather/NDVI -->
                        <div class="row" id="weatherNdviCropRow" style="display: none;">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="weather_ndvi_crops">Select Crops</label>
                                    <select name="weather_ndvi_crops[]" id="weather_ndvi_crops_select2" class="form-control"
                                        multiple>
                                        <?php $__currentLoopData = $ensuredCrops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($crop->name); ?>"><?php echo e($crop->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['weather_ndvi_crops'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="row" id="ndviBenchmarkRow" style="display: none;">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="ndvi_fixed_benchmark">NDVI Benchmark</label>
                                    <div class="input-group">
                                        <input type="number" name="ndvi_fixed_benchmark" id="ndvi_fixed_benchmark"
                                            class="form-control" value="0.4" readonly disabled>
                                        <div class="input-group-append">
                                            <span class="input-group-text">%</span>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>

                        <div class="row" id="premiumPriceWrapper" style="display: none;">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="premium_price">Premium Price</label>
                                    <div class="input-group">
                                        <input type="number" name="premium_price" id="premium_price" class="form-control">
                                        <div class="input-group-append">
                                            <span class="input-group-text" style="border: 1px solid #cbd2d8;">PKR</span>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['premium_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <!-- The required sum insured note -->
                                    <small class="text-muted mt-2 d-block" id="sumInsuredNote" style="display: none;">
                                        The premium price value applied against 1 acre
                                    </small>
                                </div>
                            </div>
                        </div>

                        <div class="benchmarkFieldsWrapper">
                            <div class="row align-items-end">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="crop">Crop</label>
                                        <select name="crop[]" class="form-control">
                                            <option value="" disabled selected>Select Crop</option>
                                            <?php $__currentLoopData = $ensuredCrops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($crop->name); ?>"><?php echo e($crop->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['crop'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <!-- District Dropdown -->
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="district_name">District</label>
                                        <!-- ADD FORM -->
                                        <select name="district_name[]" class="form-control form-select district-select">
                                            <option value="">Select District</option>
                                            <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($district->id); ?>"><?php echo e($district->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['district_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="tehsil_id">Tehsil</label>
                                        <select name="tehsil_id[]" class="form-control form-select tehsil-select">
                                            <option value="">Select Tehsil</option>
                                        </select>
                                        <?php $__errorArgs = ['tehsil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="benchmark">Benchmark</label>
                                        <div class="input-group">
                                            <input type="number" name="benchmark[0][]" class="form-control"
                                                value="<?php echo e(old('benchmark')); ?>">
                                            <div class="input-group-append">
                                                <span class="input-group-text" style="border: 1px solid #cbd2d8;">%</span>
                                            </div>
                                        </div>
                                        <?php $__errorArgs = ['benchmark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="price_benchmark">Price Benchmark</label>
                                        <div class="d-flex">
                                            <div class="input-group">
                                                <input type="number" name="price_benchmark[0][]" class="form-control"
                                                    value="<?php echo e(old('price_benchmark')); ?>">
                                                <div class="input-group-append">
                                                    <span class="input-group-text"
                                                        style="border: 1px solid #cbd2d8;">PKR</span>
                                                </div>
                                            </div>
                                            <?php $__errorArgs = ['price_benchmark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <span class="btn btn-success ml-2 addBenchmark" id="addBenchmark">
                                                <i class="fa fa-plus"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <!-- Container for dynamically added fields -->
                                <div id="benchmarksContainer" class="col-md-12"></div>
                                <div id="fieldsContainer"></div>

                                <div class="col-" style="margin-left: 20px;">
                                    <button type="button" class="btn btn-success" id="addMore">
                                        Add More <span class="ml-2 fa fa-plus"></span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Create</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <?php $__currentLoopData = $CompanyInsurances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $InsuranceType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $existingBenchmarks = explode("\n", $InsuranceType->benchmark ?? '');
            $existingPriceBenchmarks = explode("\n", $InsuranceType->price_benchmark ?? '');
        ?>

        <div class="modal fade" id="EditInsuranceTypesModal-<?php echo e($InsuranceType->id); ?>" tabindex="-1" role="dialog"
            aria-labelledby="EditInsuranceTypesModalLabel-<?php echo e($InsuranceType->id); ?>" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Insurance Type</h5>
                        <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                    </div>

                    <form action="<?php echo e(route('company.insurance.types.update', $InsuranceType->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>

                        <div class="modal-body">
                            <input type="hidden" name="incurance_company_id" value="<?php echo e($Company->id); ?>">

                            <div class="form-group">
                                <label>Insurance Type</label>
                                <input type="text" class="form-control"
                                    value="<?php echo e($InsuranceType->insuranceType->name); ?>" readonly>
                            </div>

                            <?php if($InsuranceType->insuranceType->name === 'Weather Index'): ?>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group" id="editPremiumPriceWrapper-<?php echo e($InsuranceType->id); ?>">
                                            <label for="premium_price">Premium Price</label>
                                            <div class="input-group">
                                                <input type="number" name="premium_price" class="form-control"
                                                    value="<?php echo e($InsuranceType->premium_price); ?>"
                                                    placeholder="Enter Premium Price">
                                                <div class="input-group-append">
                                                    <span class="input-group-text">PKR</span>
                                                </div>
                                            </div>
                                            <small class="text-muted mt-1 d-block">
                                                The premium price value applied against 1 acre
                                            </small>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Crop</label>
                                            <select name="crop[]" class="form-control" multiple>
                                                <option value="" disabled>Select Crop</option>
                                                <?php
                                                    $selectedCrops = is_array($InsuranceType->crop)
                                                        ? $InsuranceType->crop
                                                        : explode(',', $InsuranceType->crop);
                                                    $selectedCrops = array_map('trim', $selectedCrops); // remove whitespace
                                                ?>

                                                <?php $__currentLoopData = $ensuredCrops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($crop->name); ?>"
                                                        <?php echo e(in_array($crop->name, $selectedCrops) ? 'selected' : ''); ?>>
                                                        <?php echo e($crop->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            <?php elseif($InsuranceType->insuranceType->name === 'Satellite Index (NDVI)'): ?>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group" id="editNdviBenchmarkRow-<?php echo e($InsuranceType->id); ?>">
                                            <label>NDVI Benchmark</label>
                                            <div class="input-group">
                                                <input type="number" name="benchmark" class="form-control"
                                                    value="<?php echo e($InsuranceType->ndvi_fixed_benchmark ?? 0.4); ?>" readonly
                                                    disabled>
                                                <div class="input-group-append">
                                                    <span class="input-group-text">%</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group" id="editPremiumPriceWrapper-<?php echo e($InsuranceType->id); ?>">
                                            <label for="premium_price">Premium Price</label>
                                            <div class="input-group">
                                                <input type="number" name="premium_price" class="form-control"
                                                    value="<?php echo e($InsuranceType->premium_price); ?>"
                                                    placeholder="Enter Premium Price">
                                                <div class="input-group-append">
                                                    <span class="input-group-text">PKR</span>
                                                </div>
                                            </div>
                                            <small class="text-muted mt-1 d-block">
                                                The premium price value applied against 1 acre
                                            </small>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Crop</label>
                                            <select name="crop[]" class="form-control" multiple>
                                                <option value="" disabled>Select Crop</option>
                                                <?php
                                                    $selectedCrops = is_array($InsuranceType->crop)
                                                        ? $InsuranceType->crop
                                                        : explode(',', $InsuranceType->crop);
                                                    $selectedCrops = array_map('trim', $selectedCrops); // remove whitespace
                                                ?>

                                                <?php $__currentLoopData = $ensuredCrops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($crop->name); ?>"
                                                        <?php echo e(in_array($crop->name, $selectedCrops) ? 'selected' : ''); ?>>
                                                        <?php echo e($crop->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Crop</label>
                                            <select name="crop[]" class="form-control">
                                                <option value="" disabled>Select Crop</option>
                                                <?php $__currentLoopData = $ensuredCrops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($crop->name); ?>"
                                                        <?php echo e($InsuranceType->crop == $crop->name ? 'selected' : ''); ?>>
                                                        <?php echo e($crop->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>District</label>
                                            <select name="district_name[]" class="form-control district-select">
                                                <option value="">Select District</option>
                                                <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($district->id); ?>"
                                                        <?php echo e($InsuranceType->district_name == $district->id ? 'selected' : ''); ?>>
                                                        <?php echo e($district->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Tehsil</label>
                                            <select name="tehsil_id[]" class="form-control tehsil-select"
                                                data-selected="<?php echo e($InsuranceType->tehsil_id); ?>">
                                                <option value="">Select Tehsil</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="benchmarkContainer" data-index="<?php echo e($InsuranceType->id); ?>">
                                    <?php $__currentLoopData = $existingBenchmarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="row mb-2 benchmark-group">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Benchmark</label>
                                                    <div class="input-group">
                                                        <input type="number"
                                                            name="benchmark[<?php echo e($InsuranceType->id); ?>][]"
                                                            class="form-control" value="<?php echo e(trim($b)); ?>">
                                                        <div class="input-group-append">
                                                            <span class="input-group-text">%</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Price Benchmark</label>
                                                    <div class="d-flex">
                                                        <div class="input-group">
                                                            <input type="number"
                                                                name="price_benchmark[<?php echo e($InsuranceType->id); ?>][]"
                                                                class="form-control"
                                                                value="<?php echo e(trim($existingPriceBenchmarks[$index] ?? '')); ?>">
                                                            <div class="input-group-append">
                                                                <span class="input-group-text">PKR</span>
                                                            </div>
                                                        </div>

                                                        <?php if($index === count($existingBenchmarks) - 1): ?>
                                                            <!-- ✅ ADD THIS LINE -->
                                                            <button type="button"
                                                                class="btn btn-success ml-2 addBenchmark"
                                                                data-insurance-id="<?php echo e($InsuranceType->id); ?>">
                                                                <i class="fa fa-plus"></i>
                                                            </button>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>


                                <div id="benchmarksContainer-<?php echo e($InsuranceType->id); ?>"></div>
                            <?php endif; ?>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        
        <script>
            var existingBenchmarks_<?php echo e($InsuranceType->id); ?> = <?php echo json_encode(array_slice($existingBenchmarks, 1), 512) ?>;
            var existingPriceBenchmarks_<?php echo e($InsuranceType->id); ?> = <?php echo json_encode(array_slice($existingPriceBenchmarks, 1), 512) ?>;
        </script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <div class="main-content" style="min-height: 562px;">
        <section class="section">
            <div class="section-body">
                <div class="row">
                    <div class="col-12 col-md-12 col-lg-12">
                        <a class="btn btn-primary mb-2" href="<?php echo e(route('insurance.company.index')); ?>">Back</a>
                        <div class="card">
                            <div class="card-header">
                                <div class="col-12">
                                    <h4><?php echo e($Company->name); ?> - (Insurance types)</h4>
                                </div>
                            </div>
                            <div class="card-body table-striped table-bordered table-responsive">
                                <?php if(Auth::guard('admin')->check() ||
                                        $sideMenuPermissions->contains(fn($permission) => $permission['side_menu_name'] === 'Insurance Companies' &&
                                                $permission['permissions']->contains('create'))): ?>
                                    <a class="btn btn-primary mb-3 text-white" href="#" data-toggle="modal"
                                        data-target="#InsuranceTypesModal">Add Insurance Types</a>
                                <?php endif; ?>

                                <table class="table responsive" id="table_id_events">
                                    <thead>
                                        <tr>
                                            <th>Sr.</th>
                                            <th>Name</th>
                                            <th>Crop</th>
                                            <th>District</th>
                                            <th>Tehsil</th>
                                            <th>Benchmark % - Price</th>
                                            <th scope="col">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $CompanyInsurances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $InsuranceType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td>
                                                    <?php echo e($InsuranceType->insuranceType->name); ?>

                                                    <?php if(
                                                        ($InsuranceType->insuranceType->name === 'Weather Index' && $InsuranceType->premium_price) ||
                                                            $InsuranceType->insuranceType->name === 'Satellite Index (NDVI)'): ?>
                                                        <div class="text-muted small">
                                                            Premium Price: Rs
                                                            <?php echo e(number_format($InsuranceType->premium_price)); ?>

                                                            <?php if($InsuranceType->insuranceType->name === 'Satellite Index (NDVI)'): ?>
                                                                <br>
                                                                NDVI Benchmark:
                                                                <?php echo e($InsuranceType->benchmark ?? '0.4'); ?>%
                                                            <?php endif; ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($InsuranceType->crop); ?></td>
                                                <td class="district"><?php echo e($InsuranceType->district->name ?? ''); ?>

                                                </td>
                                                <td class="tehsil"><?php echo e($InsuranceType->tehsil->name ?? ''); ?></td>
                                                <td>
                                                    <?php if(!empty($InsuranceType->benchmark) && !empty($InsuranceType->price_benchmark)): ?>
                                                        <?php
                                                            $benchmarks = explode(
                                                                "\n",
                                                                trim($InsuranceType->benchmark),
                                                            );
                                                            $priceBenchmarks = explode(
                                                                "\n",
                                                                trim($InsuranceType->price_benchmark),
                                                            );
                                                        ?>
                                                        <ul>
                                                            <?php $__currentLoopData = $benchmarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $benchmark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if(!empty(trim($benchmark)) && !empty(trim($priceBenchmarks[$index] ?? ''))): ?>
                                                                    <li><?php echo e(trim($benchmark)); ?>% -
                                                                        <?php echo e(trim($priceBenchmarks[$index])); ?> PKR</li>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </td>

                                                <td>
                                                    <div class="d-flex gap-4">
                                                        <?php if(Auth::guard('admin')->check() ||
                                                                $sideMenuPermissions->contains(fn($permission) => $permission['side_menu_name'] === 'Insurance Companies' &&
                                                                        $permission['permissions']->contains('edit'))): ?>
                                                            <a class="btn btn-primary text-white" href="#"
                                                                data-toggle="modal"
                                                                data-target="#EditInsuranceTypesModal-<?php echo e($InsuranceType->id); ?>">Edit</a>
                                                        <?php endif; ?>

                                                        <!-- Delete Button -->
                                                        <?php if(Auth::guard('admin')->check() ||
                                                                $sideMenuPermissions->contains(fn($permission) => $permission['side_menu_name'] === 'Insurance Companies' &&
                                                                        $permission['permissions']->contains('delete'))): ?>
                                                            <form
                                                                action="
                                                        <?php echo e(route('company.insurance.types.destroy', $InsuranceType->id)); ?>

                                                            "
                                                                method="POST"
                                                                style="display:inline-block; margin-left: 10px">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <input type="hidden" name="incurance_company_id"
                                                                    value="<?php echo e($Company->id); ?>">
                                                                <button type="submit"
                                                                    class="btn btn-danger btn-flat show_confirm"
                                                                    data-toggle="tooltip">Delete</button>
                                                            </form>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {
            $('#table_id_events').DataTable()
        })
    </script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
    <script type="text/javascript">
        $('.show_confirm').click(function(event) {
            var form = $(this).closest("form");
            var name = $(this).data("name");
            event.preventDefault();
            swal({
                    title: `Are you sure you want to delete this record?`,
                    text: "If you delete this, it will be gone forever.",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        form.submit();
                    }
                });
        });
    </script>
    <script>
        $(document).ready(function() {
            $('#weather_ndvi_crops_select2').select2({
                placeholder: "Select Crops",
                width: '100%'
            });
        });

        $(document).ready(function() {
            $('select[name="crop[]"]').select2({
                placeholder: 'Select Crop(s)',
                width: '100%'
            });
        });
    </script>

    <script>
        $(document).ready(function() {
            /** ========== ADD FORM HANDLING ========== */
            $(document).on('change', '.district-select', function() {
                let $district = $(this);
                loadTehsils($district);
                // let districtId = $(this).val();
                // let $tehsilSelect = $(this).closest('.row').find('.tehsil-select');

                $tehsilSelect.empty().append('<option value="">Select Tehsil</option>');

                if (districtId) {
                    $.ajax({
                        url: `<?php echo e(route('get.tehsils', ':districtId')); ?>`.replace(':districtId',
                            districtId),
                        method: 'GET',
                        success: function(data) {
                            data.forEach(function(tehsil) {
                                $tehsilSelect.append(
                                    `<option value="${tehsil.id}">${tehsil.name}</option>`
                                );
                            });
                        },
                        error: function(xhr) {
                            console.error('Error fetching tehsils:', xhr);
                        }
                    });
                }
            });

            /** ========== EDIT FORM HANDLING ========== */
            function loadTehsils($districtSelect, selectedTehsil = null) {
                let districtId = $districtSelect.val();
                let $row = $districtSelect.closest('.row');
                let $tehsilSelect = $row.find('.tehsil-select');

                $tehsilSelect.empty().append('<option value="">Select Tehsil</option>');

                if (districtId) {
                    $.ajax({
                        url: `<?php echo e(route('get.tehsils', ':districtId')); ?>`.replace(':districtId',
                            districtId),
                        method: 'GET',
                        success: function(data) {
                            data.forEach(function(tehsil) {
                                let isSelected = selectedTehsil == tehsil.id ? 'selected' : '';
                                $tehsilSelect.append(
                                    `<option value="${tehsil.id}" ${isSelected}>${tehsil.name}</option>`
                                );
                            });
                        },
                        error: function(xhr) {
                            console.error('Error fetching tehsils:', xhr);
                        }
                    });
                }
            }

            // Handle district change for all district dropdowns
            $(document).on('change', '.district-select', function() {
                let $district = $(this);
                loadTehsils($district);
            });

            // On page load, load tehsils for all pre-filled district fields (edit case)
            $('.district-select').each(function() {
                let $district = $(this);
                let selectedTehsil = $district.data('selected-tehsil') || $district.closest('.row').find(
                    '.tehsil-select').data('selected');
                if ($district.val()) {
                    loadTehsils($district, selectedTehsil);
                }
            });
        });
    </script>


    <script>
        $(document).ready(function() {
            let benchmarkIndex = 0;

            $(document).on('click', '#addBenchmark', function() {
                benchmarkIndex++;

                let benchmarkField = `
            <div class="row align-items-end benchmark-field" data-index="${benchmarkIndex}">
                <div class="col-md-6">
                    <div class="form-group">
                        <div class="input-group">
                            <input type="number" name="benchmark[0][]" class="form-control" required>
                            <div class="input-group-append">
                                <span class="input-group-text" style="border: 1px solid #cbd2d8;">%</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <div class="d-flex">
                            <div class="input-group">
                                <input type="number" name="price_benchmark[0][]" class="form-control" required>
                                <div class="input-group-append">
                                    <span class="input-group-text" style="border: 1px solid #cbd2d8;">PKR</span>
                                </div>
                            </div>
                            <span class="btn btn-danger ml-2 removeBenchmark">
                                <i class="fa fa-trash"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        `;

                $('#benchmarksContainer').append(benchmarkField);
            });

            // Remove Benchmark Field
            $(document).on('click', '.removeBenchmark', function() {
                $(this).closest('.benchmark-field').remove();
            });
        });

        $(document).ready(function() {
            let rowIndex = 0;

            $('#addMore').click(function() {
                rowIndex++; // Increase index for each new row

                const fieldHTML = `
            <div class="row align-items-end field-group mt-4" data-index="${rowIndex}">
               <div class="col-md-4">
                    <div class="form-group">
                        <select name="crop[${rowIndex}]" class="form-control">
                            <option value="" disabled selected>Select Crop</option>
                            <?php $__currentLoopData = $ensuredCrops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($crop->name); ?>"><?php echo e($crop->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <select name="district_name[${rowIndex}]" class="form-control district-select">
                            <option value="" disabled selected>Select District</option>
                            <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($district->id); ?>"><?php echo e($district->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                         <select name="tehsil_id[${rowIndex}]" class="form-control tehsil-select">
                            <option value="" disabled selected>Select Tehsil</option>
                        </select>
                    </div>
                </div>

                <!-- Benchmark & Price Benchmark Fields -->
                <div class="col-md-12 benchmarkContainer" data-index="${rowIndex}">
                    <div class="row align-items-end benchmark-group">
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="input-group">
                                    <input type="number" name="benchmark[${rowIndex}][]" class="form-control">
                                    <div class="input-group-append">
                                        <span class="input-group-text" style="border: 1px solid #cbd2d8;">%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="d-flex">
                                    <div class="input-group">
                                        <input type="number" name="price_benchmark[${rowIndex}][]" class="form-control">
                                        <div class="input-group-append">
                                            <span class="input-group-text" style="border: 1px solid #cbd2d8;">PKR</span>
                                        </div>
                                    </div>
                                    <span class="btn btn-danger ml-2 removeField">
                                        <i class="fa fa-trash"></i>
                                    </span>
                                    <span class="btn btn-success ml-2 addBenchmark">
                                        <i class="fa fa-plus"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
                $('#fieldsContainer').append(fieldHTML);
            });

            // Append Additional Benchmark & Price Benchmark Fields
            $(document).on('click', '.addBenchmark', function() {
                let parentIndex = $(this).closest('.benchmarkContainer').data(
                    'index'); // Get the correct row index

                const extraBenchmarkHTML = `
            <div class="row align-items-end benchmark-group">
                <div class="col-md-6">
                    <div class="form-group">
                        <div class="input-group">
                            <input type="number" name="benchmark[${parentIndex}][]" class="form-control">
                            <div class="input-group-append">
                                <span class="input-group-text" style="border: 1px solid #cbd2d8;">%</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <div class="d-flex">
                            <div class="input-group">
                                <input type="number" name="price_benchmark[${parentIndex}][]" class="form-control">
                                <div class="input-group-append">
                                    <span class="input-group-text" style="border: 1px solid #cbd2d8;">PKR</span>
                                </div>
                            </div>
                            <span class="btn btn-danger ml-2 removeBenchmark">
                                <i class="fa fa-trash"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        `;

                // Append extraBenchmarkHTML inside the closest `.benchmarkContainer`
                $(this).closest('.benchmarkContainer').append(extraBenchmarkHTML);
            });

            // Remove Field (Crop, District, Tehsil & First Benchmark Set)
            $(document).on('click', '.removeField', function() {
                $(this).closest('.field-group').remove();
            });

            // Remove Individual Benchmark Fields
            $(document).on('click', '.removeBenchmark', function() {
                $(this).closest('.benchmark-group').remove();
            });
        });
    </script>

    <script>
        $(document).ready(function() {
            function toggleFieldsBasedOnType() {
                let selectedOptions = $('#insurance_type_id option:selected').map(function() {
                    return $(this).text().trim();
                }).get();

                const isWeatherIndex = selectedOptions.includes('Weather Index');
                const isNDVI = selectedOptions.includes('Satellite Index (NDVI)');

                // Always hide everything initially
                $('.modal-body .row').hide();
                $('.benchmarkFieldsWrapper').hide();
                $('#premiumPriceWrapper').hide();
                $('#ndviBenchmarkRow').hide();
                $('#sumInsuredNote').hide();
                $('#addMore').hide();
                $('#weatherNdviCropRow').hide();

                if (isWeatherIndex) {
                    $('#type').show();
                    $('#premiumPriceWrapper').show();
                    $('#sumInsuredNote').show();
                    $('#weatherNdviCropRow').show();
                } else if (isNDVI) {
                    $('#type').show();
                    $('#premiumPriceWrapper').show();
                    $('#ndviBenchmarkRow').show();
                    $('#sumInsuredNote').show();
                    $('#weatherNdviCropRow').show();
                } else {
                    // Show everything for Area Yield Index or Production Price Index
                    $('.modal-body .row').show();
                    $('.benchmarkFieldsWrapper').show();
                    $('#premiumPriceWrapper').hide();
                    $('#ndviBenchmarkRow').hide();
                    $('#sumInsuredNote').hide();
                    $('#addMore').show();
                    $('#weatherNdviCropRow').hide();

                }
            }

            // On change
            $('#insurance_type_id').on('change', toggleFieldsBasedOnType);

            // On load
            toggleFieldsBasedOnType();
        });
    </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Crop-Secure-Admin\resources\views/admin/company_insurance/type.blade.php ENDPATH**/ ?>