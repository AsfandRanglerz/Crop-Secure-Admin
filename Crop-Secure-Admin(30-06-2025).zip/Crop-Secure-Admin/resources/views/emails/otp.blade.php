<p>Your OTP code is: <strong>{{ $otp }}</strong></p>
