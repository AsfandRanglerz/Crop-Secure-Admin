<?php

namespace App\Http\Controllers\Admin;

use App\Models\Tehsil;
use App\Models\District;
use Illuminate\Http\Request;
use App\Models\InsuranceType;
use App\Models\EnsuredCropName;
use App\Models\InsuranceSubType;
use App\Http\Controllers\Controller;
use App\Models\CropInsurance;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\QueryException;
use App\Notifications\InsuranceYieldUpdated;
use App\Helpers\NotificationHelper;
use App\Models\InsuranceSubTypeSatelliteNDVI;
use App\Models\Village;
use App\Models\VillageWeatherHistory;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class InsuranceSubTypeController extends Controller
{
    // public function index($id)
    // {
    //     $sideMenuName = [];
    //     $sideMenuPermissions = [];

    //     if (Auth::guard('subadmin')->check()) {
    //         $getSubAdminPermissions = new AdminController();
    //         $subAdminData = $getSubAdminPermissions->getSubAdminPermissions();
    //         $sideMenuName = $subAdminData['sideMenuName'];
    //         $sideMenuPermissions = $subAdminData['sideMenuPermissions'];
    //     }
    //     $ensuredCrops = EnsuredCropName::all();  // Fetch all crops
    //     $districts = District::all();         // Fetch all districts
    //     $tehsils = Tehsil::all();             // Fetch all tehsils
    //     $InsuranceType = InsuranceType::find($id);
    //     $InsuranceSubTypes = InsuranceSubType::with(['district', 'tehsil'])->where('incurance_type_id', $id)->orderBy('status', 'desc')->latest()->get();

    //     return view('admin.insurance_types_and_sub_types.sub_types', compact('sideMenuPermissions', 'sideMenuName', 'InsuranceSubTypes', 'InsuranceType', 'ensuredCrops', 'districts', 'tehsils'));
    // }

    public function index($id)
    {
        $sideMenuName = [];
        $sideMenuPermissions = [];

        if (Auth::guard('subadmin')->check()) {
            $getSubAdminPermissions = new AdminController();
            $subAdminData = $getSubAdminPermissions->getSubAdminPermissions();
            $sideMenuName = $subAdminData['sideMenuName'];
            $sideMenuPermissions = $subAdminData['sideMenuPermissions'];
        }

        $ensuredCrops = EnsuredCropName::all();
        $districts = District::all();
        $tehsils = Tehsil::all();
        $InsuranceType = InsuranceType::find($id);
        $InsuranceSubTypes = InsuranceSubType::with(['district', 'tehsil'])
            ->where('incurance_type_id', $id)
            ->orderBy('status', 'desc')
            ->latest()
            ->get();

        return view('admin.insurance_types_and_sub_types.sub_types', compact(
            'sideMenuPermissions',
            'sideMenuName',
            'InsuranceType',
            'InsuranceSubTypes',
            'ensuredCrops',
            'districts',
            'tehsils'
        ));
    }


    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'district_id' => 'required',
            'tehsil_id' => 'required',
            'current_yield' => 'required|numeric',
            'year' => 'required|integer',
        ]);

        $insuranceSubType = InsuranceSubType::create([
            'incurance_type_id' => $request->incurance_type_id,
            'name' => $request->name,
            'district_id' => $request->district_id,
            'tehsil_id' => $request->tehsil_id,
            'current_yield' => $request->current_yield,
            'year' => $request->year,
        ]);

        $farmers = CropInsurance::with('user')
            ->where('crop', $request->name)
            ->where('district_id', $request->district_id)
            ->where('tehsil_id', $request->tehsil_id)
            ->where('year', $request->year)
            ->get();

        foreach ($farmers as $record) {
            $benchmark = $record->benchmark_percent;
            $area = $record->area;
            $sumInsuredBase = $record->sum_insured_100_percent;
            $sumInsured = ($benchmark / 100) * ($sumInsuredBase * $area);
            $lossPercentage = $benchmark - $request->current_yield;

            $compensation = 0;
            $status = 'no loss';
            if ($lossPercentage > 0) {
                $compensation = ($lossPercentage / 100) * $sumInsured;
                $status = 'loss';
            }

            $record->update([
                'compensation' => $compensation,
                'status' => $status,
            ]);

            $user = $record->user;
            if ($user && $user->fcm_token) {
                NotificationHelper::sendFcmNotification(
                    $user->fcm_token,
                    'Insurance Update: ' . $record->crop,
                    $compensation > 0
                        ? 'You are eligible for Rs. ' . number_format($compensation)
                        : 'No compensation. Yield met or exceeded benchmark.',
                    [
                        'compensation' => $compensation,
                        'status' => $status,
                        'crop' => $record->crop,
                        'year' => $record->year,
                        'area' => $area,
                        'benchmark' => $benchmark,
                        'current_yield' => $request->current_yield,
                        'sum_insured' => $sumInsured,
                        'sum_insured_base' => $sumInsuredBase,
                    ]
                );
            }
        }

        return redirect()
            ->route('insurance.sub.type.index', ['id' => $request->incurance_type_id])
            ->with(['message' => 'Yield recorded and farmers notified successfully']);
    }

    public function update(Request $request, $id)
    {
        // dd($request);

        $request->validate([
            'name' => 'required',
            'district_id' => 'required',
            'tehsil_id' => 'required',
            'current_yield' => 'required|numeric',
            'year' => 'required|integer',
        ]);

        $data = InsuranceSubType::findOrFail($id);

        $data->update([
            'name' => $request->name,
            'district_id' => $request->district_id,
            'tehsil_id' => $request->tehsil_id,
            'current_yield' => $request->current_yield,
            'year' => $request->year,
            // 'status' => $request->status,
        ]);

        return redirect()->route('insurance.sub.type.index', ['id' => $request->incurance_type_id])->with(['message' => 'Insurance Sub-Type Updated Successfully']);
    }

    public function destroy(Request $request, $id)
    {
        // dd($request);
        try {
            InsuranceSubType::destroy($id);
            return redirect()->route('insurance.sub.type.index', ['id' => $request->incurance_type_id])->with(['message' => 'Insurance Sub-Type Deleted Successfully']);
        } catch (QueryException $e) {
            return redirect()->route('insurance.sub.type.index', ['id' => $request->incurance_type_id])->with(['error' => 'This insurance Sub-type cannot be deleted because it is assigned to insurance companies.']);
        }
    }

    public function production_price($id)
    {
        $sideMenuName = [];
        $sideMenuPermissions = [];

        if (Auth::guard('subadmin')->check()) {
            $getSubAdminPermissions = new AdminController();
            $subAdminData = $getSubAdminPermissions->getSubAdminPermissions();
            $sideMenuName = $subAdminData['sideMenuName'];
            $sideMenuPermissions = $subAdminData['sideMenuPermissions'];
        }
        $ensuredCrops = EnsuredCropName::all();  // Fetch all crops
        $districts = District::all();         // Fetch all districts
        $tehsils = Tehsil::all();             // Fetch all tehsils
        $InsuranceType = InsuranceType::find($id);
        $InsuranceSubTypes = InsuranceSubType::with(['district', 'tehsil', 'crop'])
            ->where('incurance_type_id', $id)
            ->orderBy('status', 'desc')
            ->latest()
            ->get();

        return view('admin.insurance_types_and_sub_types.sub_types_production_price', compact('sideMenuPermissions', 'sideMenuName', 'InsuranceSubTypes', 'InsuranceType', 'ensuredCrops', 'districts', 'tehsils'));
    }

    public function production_price_store(Request $request)
    {
        //dd($request);
        $request->validate([
            'incurance_type_id' => 'required|integer',
            'crop_name_id' => 'required|integer',
            'year' => 'required|integer',
            'crops' => 'required|array',
            'crops.*.district_id' => 'required|integer',
            'crops.*.tehsil_id' => 'required|integer', //  validate tehsil_id inside crops array
            //  'crops.*.cost_of_production' => 'required|numeric',
            // 'crops.*.average_yield' => 'required|numeric',
            // 'crops.*.historical_average_market_price' => 'required|numeric',
            // 'crops.*.real_time_market_price' => 'required|numeric',
            // 'crops.*.ensured_yield' => 'required|numeric',
        ]);


        foreach ($request->crops as $crop) {
            InsuranceSubType::create([
                'crop_name_id' => $request->crop_name_id,
                'incurance_type_id' => $request->incurance_type_id,
                'district_id' => $crop['district_id'] ?? null,
                'tehsil_id' => $crop['tehsil_id'] ?? null,
                'cost_of_production' => $crop['cost_of_production'],
                'average_yield' => $crop['average_yield'] ?? null,
                'historical_average_market_price' => $crop['historical_average_market_price'] ?? null,
                'real_time_market_price' => $crop['real_time_market_price'] ?? null,
                'ensured_yield' => $crop['ensured_yield'] ?? null,
                'year' => $request->year,
            ]);
        }

        //dd($request->toArray());

        return redirect()->route('insurance.sub.type.productionPrice', ['id' => $request->incurance_type_id])
            ->with(['message' => 'Insurance Sub-Types Created Successfully']);
    }


    public function production_price_update(Request $request, $id)
    {
        //dd($request);

        $request->validate([
            'crop_name_id' => 'required|exists:insurance_types,id',
            'crops.0.district_id' => 'required|exists:districts,id',
            'crops.0.tehsil_id' => 'required|exists:tehsils,id',
            'cost_of_production' => 'nullable|numeric',
            // 'average_yield' => 'nullable|numeric',
            // 'historical_average_market_price' => 'nullable|numeric',
            // 'real_time_market_price' => 'nullable|numeric',
            //'ensured_yield' => 'nullable|numeric',
            //'year' => 'required',
        ]);

        $insuranceSubType = InsuranceSubType::findOrFail($id);

        $insuranceSubType->crop_name_id = $request->input('crop_name_id');
        $insuranceSubType->district_id = $request->input('crops.0.district_id');
        $insuranceSubType->tehsil_id = $request->input('crops.0.tehsil_id');
        $insuranceSubType->cost_of_production = $request->input('cost_of_production');
        $insuranceSubType->average_yield = $request->input('average_yield');
        $insuranceSubType->historical_average_market_price = $request->input('historical_average_market_price');
        $insuranceSubType->real_time_market_price = $request->input('real_time_market_price');
        $insuranceSubType->ensured_yield = $request->input('ensured_yield');
        $insuranceSubType->year = $request->input('year');

        $insuranceSubType->save();



        return redirect()->route('insurance.sub.type.productionPrice', ['id' => $request->incurance_type_id])->with(['message' => 'Insurance Sub-Type Updated Successfully']);
    }

    public function production_price_destroy(Request $request, $id)
    {
        // dd($request->toArray());
        try {
            InsuranceSubType::destroy($id);
            return redirect()->route('insurance.sub.type.productionPrice', ['id' => $request->incurance_type_id])->with(['message' => 'Insurance Sub-Type Deleted Successfully']);
        } catch (QueryException $e) {
            return redirect()->route('insurance.sub.type.productionPrice', ['id' => $request->incurance_type_id])->with(['error' => 'This insurance Sub-type cannot be deleted because it is assigned to insurance companies.']);
        }
    }


    public function satellite_ndvi($id)
    {
        $sideMenuName = [];
        $sideMenuPermissions = [];

        if (Auth::guard('subadmin')->check()) {
            $getSubAdminPermissions = new AdminController();
            $subAdminData = $getSubAdminPermissions->getSubAdminPermissions();
            $sideMenuName = $subAdminData['sideMenuName'];
            $sideMenuPermissions = $subAdminData['sideMenuPermissions'];
        }

        $ensuredCrops = EnsuredCropName::all();
        $districts = District::all();
        $tehsils = Tehsil::all();
        $InsuranceType = InsuranceType::find($id);

        // 🟢 Fetch NDVI records, not subtypes
        $InsuranceSubTypes = InsuranceSubTypeSatelliteNDVI::where('insurance_type_id', $id)
            ->orderBy('date', 'desc')
            ->get();

        return view('admin.insurance_types_and_sub_types.sub_types_satelliteNDVI', compact(
            'sideMenuPermissions',
            'sideMenuName',
            'InsuranceSubTypes',
            'InsuranceType',
            'ensuredCrops',
            'districts',
            'tehsils'
        ));
    }


    public function fetchNDVIData(Request $request)
    {
        // Log initial request input
        Log::info('NDVI fetch request received', $request->all());

        // Validate input
        $request->validate([
            'date' => 'required|date',
        ]);

        try {
            $apiKey = 'apk.ec114200944764f1f5162bf2efc7cd4ccb9afb90efaa35594cf3058b0244d6da';
            $apiUrl = 'https://api-connect.eos.com/user-dashboard/statistics';

            // Send API request
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $apiKey,
                'Accept' => 'application/json',
            ])->get($apiUrl, [
                'date' => $request->date,
            ]);

            // Log raw response body
            Log::info('EOS NDVI raw response', [
                'status' => $response->status(),
                'body' => $response->body(),
            ]);

            // If successful, process data
            if ($response->successful()) {
                $data = $response->json();

                $b8 = isset($data['B8']) ? floatval($data['B8']) : 0.0;
                $b4 = isset($data['B4']) ? floatval($data['B4']) : 0.0;

                // Log band values
                Log::info('NDVI band values', [
                    'B8' => $b8,
                    'B4' => $b4,
                    'B8 + B4' => $b8 + $b4,
                ]);

                // Prevent division by zero
                if (($b8 + $b4) == 0.0) {
                    Log::warning('NDVI calculation skipped due to division by zero', [
                        'B8' => $b8,
                        'B4' => $b4
                    ]);

                    return response()->json([
                        'error' => 'Invalid B8/B4 values (division by zero)',
                        'b8' => $b8,
                        'b4' => $b4,
                        'ndvi' => null
                    ], 422);
                }

                $ndvi = ($b8 - $b4) / ($b8 + $b4);

                return response()->json([
                    'b8' => $b8,
                    'b4' => $b4,
                    'ndvi' => round($ndvi, 4)
                ]);
            }

            // Handle unsuccessful EOS API response
            Log::error('EOS API request failed', [
                'status' => $response->status(),
                'body' => $response->body()
            ]);

            return response()->json(['error' => 'Data not found or EOS request failed'], $response->status());
        } catch (\Exception $e) {
            // Log internal error
            Log::error('NDVI API Exception', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json(['error' => 'Internal server error'], 500);
        }
    }

    // Manually store a record from the modal
    public function satellite_ndvi_store(Request $request)
    {
        $request->validate([
            'date' => 'required|date',
            'b8' => 'required|numeric|min:0|max:999999999999999',
            'b4' => 'required|numeric|min:0|max:999999999999999',
            'ndvi' => 'required|numeric',
            'incurance_type_id' => 'nullable|exists:insurance_types,id',
        ]);

        // Step 1: Save the NDVI record
        $ndviRecord = InsuranceSubTypeSatelliteNDVI::create([
            'date' => $request->date,
            'b8' => $request->b8,
            'b4' => $request->b4,
            'ndvi' => $request->ndvi,
            'insurance_type_id' => $request->incurance_type_id,
        ]);

        // Step 2: Notify all farmers who purchased Satellite NDVI insurance
        $farmers = CropInsurance::with('user')
            ->where('insurance_type', 'Satellite Index')
            ->get();

        foreach ($farmers as $record) {
            $user = $record->user;
            if ($user && $user->fcm_token) {
                \App\Helpers\NotificationHelper::sendFcmNotification(
                    $user->fcm_token,
                    'Satellite NDVI Update',
                    'New NDVI data is available for your insured crop.',
                    [
                        'date' => $ndviRecord->date,
                        'b8' => $ndviRecord->b8,
                        'b4' => $ndviRecord->b4,
                        'ndvi' => $ndviRecord->ndvi,
                    ]
                );
            }
        }

        return back()->with('success', 'NDVI entry saved and farmers notified.');
    }


    // Delete an entry
    public function satellite_ndvi_destroy($id)
    {
        InsuranceSubTypeSatelliteNDVI::findOrFail($id)->delete();
        return back()->with('success', 'NDVI record deleted successfully.');
    }

    public function weather_index($id)
    {
        $sideMenuName = [];
        $sideMenuPermissions = [];

        if (Auth::guard('subadmin')->check()) {
            $getSubAdminPermissions = new AdminController();
            $subAdminData = $getSubAdminPermissions->getSubAdminPermissions();
            $sideMenuName = $subAdminData['sideMenuName'];
            $sideMenuPermissions = $subAdminData['sideMenuPermissions'];
        }
        $InsuranceType = InsuranceType::find($id);
        $InsuranceSubTypes = Village::get();


        return view('admin.insurance_types_and_sub_types.sub_types_weather_index', compact('sideMenuPermissions', 'sideMenuName', 'InsuranceSubTypes', 'InsuranceType'));
    }


    public function showVillageResult($id)
    {
        $village = Village::findOrFail($id);

        // Show last 14 days weather
        $villageWeathers = VillageWeatherHistory::with('village')
                        ->where('village_id', $id)
                        ->latest()
                        ->get();

        return view('admin.insurance_types_and_sub_types.weather_index_result', compact('village','villageWeathers'));
    }
}
